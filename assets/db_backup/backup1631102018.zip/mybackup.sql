#
# TABLE STRUCTURE FOR: mlm_transaction
#

DROP TABLE IF EXISTS `mlm_transaction`;

CREATE TABLE `mlm_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `status` enum('paid','unpaid') NOT NULL,
  `refid` int(11) NOT NULL,
  `remark` varchar(200) NOT NULL,
  `transtype` varchar(50) NOT NULL,
  `wallettype` varchar(50) NOT NULL,
  `netamount` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `wallettype` (`wallettype`),
  KEY `netamount` (`netamount`),
  KEY `entrydate` (`entrydate`,`userid`,`transtype`,`wallettype`,`netamount`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (1, '2021-09-07 11:46:16', 1, 2, 'paid', 1, 'Level Income : 1', 'Level Income', 'Income Wallet', '65');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (2, '2021-09-07 12:59:48', 1, 0, 'paid', 1, 'Wallet Request Accepted', 'Added To Wallet', 'Repurchase Wallet', '1000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (3, '2021-09-07 13:00:19', 3, 1, 'paid', 1, 'Fund Received', 'Fund Received', 'Repurchase Wallet', '100');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (4, '2021-09-07 13:00:19', 1, 3, 'paid', 1, 'Fund Received', 'Fund Transfer', 'Repurchase Wallet', '-100');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (5, '2021-09-07 13:00:45', 1, 0, 'paid', 2, 'Admin Added Wallet', 'Added To Wallet', 'Repurchase Wallet', '1000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (6, '2021-09-07 13:01:16', 1, 0, 'paid', 3, 'Admin Deduct Wallet', 'Deduct To Wallet', 'Repurchase Wallet', '-1000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (7, '2021-09-07 13:01:31', 1, 0, 'paid', 4, 'Admin Deduct Wallet', 'Deduct To Wallet', 'Repurchase Wallet', '-2000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (8, '2021-09-07 13:01:58', 1, 0, 'paid', 5, 'Admin Added Wallet', 'Added To Wallet', 'Repurchase Wallet', '2100');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (9, '2021-09-07 13:03:53', 1, 0, 'paid', 2, 'Re-Purchase - 2021-22/2', 'Repurchase', 'Repurchase Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (10, '2021-09-07 13:10:12', 1, 0, 'paid', 3, 'Re-Purchase - 2021-22/3', 'Repurchase', 'Repurchase Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (11, '2021-09-07 15:29:23', 2, 0, 'paid', 6, 'Admin Added Wallet', 'Added To Wallet', 'Repurchase Wallet', '1000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (12, '2021-09-07 15:29:31', 2, 0, 'paid', 4, 'Re-Purchase - 2021-22/4', 'Repurchase', 'Repurchase Wallet', '-1000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (13, '2021-09-07 15:29:31', 1, 2, 'paid', 1, 'Repurchase Income : 1', 'Repurchase Income', 'Income Wallet', '100');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (14, '2021-09-07 17:22:59', 1, 0, 'paid', 7, 'Admin Added Wallet', 'Added To Wallet', 'Repurchase Wallet', '1000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (15, '2021-09-07 17:23:27', 2, 1, 'paid', 2, 'Fund Received', 'Fund Received', 'Repurchase Wallet', '150');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (16, '2021-09-07 17:23:27', 1, 2, 'paid', 2, 'Fund Received', 'Fund Transfer', 'Repurchase Wallet', '-150');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (17, '2021-09-07 17:26:14', 2, 1, 'paid', 3, 'Fund Received', 'Fund Received', 'Repurchase Wallet', '160');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (18, '2021-09-07 17:26:14', 1, 2, 'paid', 3, 'Fund Transfer', 'Fund Transfer', 'Repurchase Wallet', '-160');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (19, '2021-09-07 17:26:40', 1, 0, 'paid', 1, 'Income Wallet To Repurchase Wallet Transfer', 'Fund Received', 'Repurchase Wallet', '100');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (20, '2021-09-07 17:26:40', 1, 0, 'paid', 1, 'Income Wallet To Repurchase Wallet Transfer', 'Fund Transfer', 'Income Wallet', '-100');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (21, '2021-09-07 17:27:20', 1, 0, 'paid', 2, 'Repurchase Wallet To Income Wallet Transfer', 'Fund Transfer', 'Repurchase Wallet', '-98');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (22, '2021-09-07 17:27:20', 1, 0, 'paid', 2, 'Repurchase Wallet to Income Wallet Transfer Admin Charge', 'Fund Transfer', 'Repurchase Wallet', '-2');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (23, '2021-09-07 17:27:20', 1, 0, 'paid', 2, 'Repurchase Wallet To Income Wallet Transfer', 'Fund Received', 'Income Wallet', '98');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (24, '2021-09-07 17:55:59', 2, 0, 'paid', 8, 'Admin Added Wallet', 'Added To Wallet', 'Repurchase Wallet', '10000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (25, '2021-09-07 18:03:43', 2, 2, 'paid', 3, 'Pin Generated', 'Pin Generate', 'Repurchase Wallet', '-2500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (26, '2021-09-07 18:24:46', 2, 5, 'paid', 2, 'Level Income : 1', 'Level Income', 'Income Wallet', '65');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (27, '2021-09-07 18:24:46', 1, 5, 'paid', 3, 'Level Income : 2', 'Level Income', 'Income Wallet', '25');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (28, '2021-09-07 18:28:55', 2, 6, 'paid', 4, 'Level Income : 1', 'Level Income', 'Income Wallet', '65');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (29, '2021-09-07 18:28:55', 1, 6, 'paid', 5, 'Level Income : 2', 'Level Income', 'Income Wallet', '25');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (30, '2021-09-07 19:04:45', 1, 0, 'paid', 1, 'Reward Income', 'Reward Income', 'Income Wallet', '2000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (31, '2021-09-07 19:04:45', 2, 0, 'paid', 2, 'Reward Income', 'Reward Income', 'Income Wallet', '2000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (32, '2021-09-07 19:04:45', 6, 0, 'paid', 3, 'Reward Income', 'Reward Income', 'Income Wallet', '2000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (33, '2021-09-07 19:04:45', 1, 0, 'paid', 4, 'Reward Income', 'Reward Income', 'Income Wallet', '6000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (34, '2021-09-07 19:04:45', 2, 0, 'paid', 5, 'Reward Income', 'Reward Income', 'Income Wallet', '6000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (35, '2021-09-08 16:01:52', 1, 0, 'paid', 1, 'Withdrawal Request', 'Withdrawal Request', 'Income Wallet', '-7638.09');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (36, '2021-09-08 16:01:52', 1, 0, 'paid', 1, 'Withdrawal Request TDS', 'Withdrawal Request', 'Income Wallet', '-410.65');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (37, '2021-09-08 16:01:52', 1, 0, 'paid', 1, 'Withdrawal Request Admin Charge', 'Withdrawal Request', 'Income Wallet', '-164.26');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (38, '2021-09-08 16:31:51', 1, 0, 'paid', 1, 'Withdrawal Request Rejected', 'Withdrawal Request Rejected', 'Income Wallet', '7638.09');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (39, '2021-09-08 16:31:51', 1, 0, 'paid', 1, 'Withdrawal Request Rejected', 'Withdrawal Request Rejected TDS', 'Income Wallet', '410.65');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (40, '2021-09-08 16:31:51', 1, 0, 'paid', 1, 'Withdrawal Request Rejected Admin Charge', 'Withdrawal Request Rejected', 'Income Wallet', '164.26');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (41, '2021-09-08 16:32:24', 1, 0, 'paid', 2, 'Withdrawal Request', 'Withdrawal Request', 'Income Wallet', '-7638.09');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (42, '2021-09-08 16:32:24', 1, 0, 'paid', 2, 'Withdrawal Request TDS', 'Withdrawal Request', 'Income Wallet', '-410.65');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (43, '2021-09-08 16:32:24', 1, 0, 'paid', 2, 'Withdrawal Request Admin Charge', 'Withdrawal Request', 'Income Wallet', '-164.26');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (44, '2021-09-08 16:38:09', 1, 0, 'paid', 3, 'Repurchase Wallet To Income Wallet Transfer', 'Fund Transfer', 'Repurchase Wallet', '-98');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (45, '2021-09-08 16:38:09', 1, 0, 'paid', 3, 'Repurchase Wallet to Income Wallet Transfer Admin Charge', 'Fund Transfer', 'Repurchase Wallet', '-2');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (46, '2021-09-08 16:38:09', 1, 0, 'paid', 3, 'Repurchase Wallet To Income Wallet Transfer', 'Fund Received', 'Income Wallet', '-98');


#
# TABLE STRUCTURE FOR: mlm_userdetail
#

DROP TABLE IF EXISTS `mlm_userdetail`;

CREATE TABLE `mlm_userdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `fname` text NOT NULL,
  `mname` text NOT NULL,
  `lname` text NOT NULL,
  `fullname` text NOT NULL,
  `dob` varchar(50) NOT NULL,
  `sex` text NOT NULL,
  `regtype` enum('0','1') NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `whatsapp` bigint(20) NOT NULL,
  `address` varchar(150) NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `country` text NOT NULL,
  `bankname` text,
  `banktype` text,
  `bankifsc` varchar(50) NOT NULL,
  `bankaccno` varchar(50) NOT NULL,
  `bankbranch` text NOT NULL,
  `bankaccname` text NOT NULL,
  `panno` varchar(15) NOT NULL,
  `pincode` varchar(15) NOT NULL,
  `nominee` varchar(100) NOT NULL,
  `nomineerel` varchar(50) DEFAULT NULL,
  `profile` text NOT NULL,
  `district` varchar(50) NOT NULL,
  `secretque` text NOT NULL,
  `secretans` text NOT NULL,
  `maritalstatus` varchar(50) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `micrcode` varchar(50) NOT NULL,
  `aadharcard` bigint(20) NOT NULL,
  `panacceptid` int(11) NOT NULL,
  `aadhaaracceptid` int(11) NOT NULL,
  `bankacceptid` int(11) NOT NULL,
  `leftreward` int(11) NOT NULL,
  `rightreward` int(11) NOT NULL,
  `gapcomid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`) VALUES (1, 1, '', 'Company ID', '', '', 'Company ID', '1998-07-09 00:00:00', 'M', '0', 'asd@gmail.com', '8521479630', '0', 'sadasd', '10', '2', '', 'THE ROYAL BANK OF SCOTLAND N V', 'Current', 'SBIN01234f6', '85217479630', 'ASDFG', 'ASDFG', '', '364005', '', '', '', '', '', '', '', '', '', '0', 0, 0, 0, 0, 0, 0);
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`) VALUES (2, 2, '', '1', '', '', '1', '', '', '0', '', '8521478520', '0', 'sdfsdfsd', '318', '4', '', NULL, NULL, '', '', '', '', 'ASDFG1234q', '364005', '', NULL, '', '', '', '', '', '', '', '0', 0, 2, 0, 0, 0, 0);
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`) VALUES (3, 3, '', '2', '', '', '2', '', '', '0', '', '8521478520', '0', 'sdfsdfsd', '8', '2', '', NULL, NULL, '', '', '', '', '', '364005', '', NULL, '', '', '', '', '', '', '', '0', 0, 0, 0, 0, 0, 0);
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`) VALUES (4, 4, '', '3', '', '', '3', '', '', '0', '', '8521478520', '0', 'sdfsdfsd', '301', '3', '', NULL, NULL, '', '', '', '', '', '364005', '', NULL, '', '', '', '', '', '', '', '0', 0, 0, 0, 0, 0, 0);
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`) VALUES (5, 5, '', 'harshit', '', '', 'harshit', '', '', '0', '', '8690311818', '0', 'asdasdasd', '301', '3', '', NULL, NULL, '', '', '', '', '', '364005', '', NULL, '', '', '', '', '', '', '', '0', 0, 0, 0, 0, 0, 0);
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`) VALUES (6, 6, '', '54654', '', '', '54654', '', '', '0', '', '8555555555', '0', 'dsfsdsd', '302', '3', '', NULL, NULL, '', '', '', '', '', '364005', '', NULL, '', '', '', '', '', '', '', '0', 0, 0, 0, 0, 0, 0);


#
# TABLE STRUCTURE FOR: mlm_userlogin
#

DROP TABLE IF EXISTS `mlm_userlogin`;

CREATE TABLE `mlm_userlogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `activedate` datetime DEFAULT NULL,
  `purchasestatus` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=Inactive 1=Active',
  `puchasedate` datetime NOT NULL,
  `activestatus` enum('0','1') NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `usernamechange` enum('yes','no') NOT NULL DEFAULT 'no',
  `clubid` int(2) NOT NULL DEFAULT '1',
  `status` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0: Member 1: Visitor',
  `statusdate` datetime NOT NULL,
  `lastlogindate` datetime NOT NULL,
  `currlogindate` datetime NOT NULL,
  `lastloginip` varchar(50) NOT NULL,
  `currloginip` varchar(50) NOT NULL,
  `lastpayoutdate` datetime NOT NULL,
  `packagecode` int(11) NOT NULL,
  `securitypassword` varchar(500) DEFAULT NULL,
  `kyc` int(11) NOT NULL,
  `panstatus` enum('0','1','2','3') NOT NULL COMMENT '0: Not Uploaded, 1: Accept, 2: Reject, 3: Pending ',
  `bankstatus` enum('0','1','2','3') NOT NULL COMMENT '0: Not Uploaded, 1: Accept, 2: Reject, 3: Pending ',
  `adharstatus` enum('0','1','2','3') NOT NULL COMMENT '0: Not Uploaded, 1: Accept, 2: Reject, 3: Pending ',
  `lastbinarydate` datetime NOT NULL,
  `bfl` float NOT NULL,
  `bfr` float NOT NULL,
  `tail` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0 : No, 1: Yes',
  `taildate` datetime NOT NULL,
  `bflbv` float NOT NULL,
  `bfrbv` float NOT NULL,
  `lockmember` enum('0','1','2') NOT NULL COMMENT '0=unlock 1=lock 2=softlock',
  `designation` int(11) NOT NULL,
  `sleft` int(11) NOT NULL,
  `sright` int(11) NOT NULL,
  `memtype` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=default 1=master',
  `boosterLeft` int(11) NOT NULL,
  `boosterRight` int(11) NOT NULL,
  `joinfrom` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0:web,1:android,2:ios',
  `leaderid` int(11) NOT NULL,
  `tmpleaderid` int(11) NOT NULL,
  `rightsponsor` int(11) NOT NULL,
  `leftsponsor` int(11) NOT NULL,
  `inactivesponsor` int(11) NOT NULL,
  `activeleftsponsor` int(11) NOT NULL,
  `activerightsponsor` int(11) NOT NULL,
  `activesponsor` int(11) NOT NULL,
  `tensponsorincome` int(11) NOT NULL DEFAULT '0',
  `capping` int(11) NOT NULL,
  `oldcapping` int(11) NOT NULL,
  `totalmp` int(11) NOT NULL,
  `wocaptotalmp` int(11) NOT NULL,
  `totalcut` int(11) NOT NULL,
  `deliverflag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:false,1:true',
  `deliverdate` datetime NOT NULL,
  `rewardid` int(11) NOT NULL,
  `generationid` int(11) NOT NULL,
  `selfpurchase` float NOT NULL,
  `downlinepurchase` float NOT NULL,
  `previouspurchase` float NOT NULL,
  `per` float NOT NULL,
  `repurchasedate` datetime NOT NULL,
  `counttotalleg` int(11) NOT NULL DEFAULT '0',
  `royaltymp` float NOT NULL,
  `royaltymonthmp` float NOT NULL,
  `royaltyeligible` int(11) NOT NULL,
  `calculationdate` datetime NOT NULL,
  `expiredate` datetime NOT NULL,
  `renewal` enum('0','1') NOT NULL DEFAULT '0',
  `multiply` int(11) NOT NULL,
  `tmpreneal` enum('0','1') NOT NULL DEFAULT '0',
  `mainincome` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=No 1=Yes',
  `teambv` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `id` (`id`),
  KEY `activeleftsponsor` (`activeleftsponsor`),
  KEY `activerightsponsor` (`activerightsponsor`),
  KEY `activestatus` (`activestatus`),
  KEY `sleft` (`sleft`),
  KEY `sright` (`sright`),
  KEY `lastbinarydate` (`lastbinarydate`),
  KEY `bfl` (`bfl`),
  KEY `bfr` (`bfr`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`) VALUES (1, '2021-08-18 12:13:19', '2021-08-21 12:13:19', '0', '0000-00-00 00:00:00', '1', '456789', '123', 'no', 3, '0', '0000-00-00 00:00:00', '2018-10-23 13:56:23', '2018-11-01 17:54:05', '', '', '2021-03-15 23:59:59', 1, '781574', 4, '1', '1', '1', '2021-05-01 23:59:59', '0', '29', '1', '2018-12-10 23:59:59', '0', '378.375', '0', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 2, 0, '0', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '2021-05-06 23:59:59', '2021-05-06 23:59:59', '0', 0, '0', '0', 520);
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`) VALUES (2, '2021-09-07 11:44:58', '2021-09-07 11:46:16', '1', '2021-09-07 11:46:16', '1', '3174582', '1234', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, '', 0, '1', '0', '2', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 2, 0, '0', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '2021-09-07 11:46:16', '0000-00-00 00:00:00', '0', 0, '0', '0', 1000);
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`) VALUES (3, '2021-09-07 11:45:15', NULL, '0', '0000-00-00 00:00:00', '0', '4923518', '1234', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 0, '', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '0', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0);
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`) VALUES (4, '2021-09-07 11:45:35', NULL, '0', '0000-00-00 00:00:00', '0', '1867492', '1234', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 0, '', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '0', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0);
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`) VALUES (5, '2021-09-07 18:24:13', '2021-09-07 18:24:46', '1', '2021-09-07 18:24:46', '1', '7413968', '1234', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, '', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '0', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '2021-09-07 18:24:46', '0000-00-00 00:00:00', '0', 0, '0', '0', 101);
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`) VALUES (6, '2021-09-07 18:27:51', '2021-09-07 18:28:55', '1', '2021-09-07 18:28:55', '1', '3591472', '1234', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, '', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 1, 0, '0', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '2021-09-07 18:28:55', '0000-00-00 00:00:00', '0', 0, '0', '0', 300);


#
# TABLE STRUCTURE FOR: mlm_userdownline
#

DROP TABLE IF EXISTS `mlm_userdownline`;

CREATE TABLE `mlm_userdownline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `sponsor` int(11) NOT NULL,
  `upline` int(11) NOT NULL,
  `side` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0:left,1:middle,2:right',
  `lockplace` int(11) NOT NULL DEFAULT '0',
  `monthleftpv` float NOT NULL,
  `leftbv` float NOT NULL,
  `monthrightpv` float NOT NULL,
  `rightbv` float NOT NULL,
  `mp` float NOT NULL,
  `capping` float NOT NULL,
  `directincome` float NOT NULL,
  `eligible` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0- yes, 1-No',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `sponsor` (`sponsor`),
  KEY `upline` (`upline`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (1, 2, 1, 1, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (2, 3, 1, 1, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (3, 4, 1, 1, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (4, 5, 2, 2, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (5, 6, 2, 2, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');


#
# TABLE STRUCTURE FOR: mlm_useractivation
#

DROP TABLE IF EXISTS `mlm_useractivation`;

CREATE TABLE `mlm_useractivation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `activedate` datetime DEFAULT NULL COMMENT 'Status Update Date',
  `userid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `packagecode` int(11) NOT NULL,
  `activetype` enum('0','1') NOT NULL COMMENT '0:pin 1=wallet',
  `activepin` varchar(100) NOT NULL,
  `activeamount` float NOT NULL,
  `packagetax` float NOT NULL,
  `netamount` float NOT NULL,
  `bv` float NOT NULL,
  `pv` float NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0:accept,1:pending,2:reject',
  `statusby` int(10) NOT NULL,
  `type` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:Registration,1:Topup',
  `kitid` int(11) NOT NULL,
  `dispatch` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=No 1=Yes',
  `dispatchdate` datetime NOT NULL,
  `dispatchby` int(11) NOT NULL,
  `docateno` varchar(100) NOT NULL,
  `lockpackage` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=No 1=Yes',
  `joinfrom` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0:web,1:android,2:ios',
  `olddata` int(11) NOT NULL,
  `renew` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrydate` (`entrydate`),
  KEY `activedate` (`activedate`),
  KEY `pv` (`pv`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (1, '2021-09-07 11:46:16', '2021-09-07 11:46:16', 2, 1, 1, '0', 'ANOFV3GWM4E', '500', '0', '500', '0', '1', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (2, '2021-09-07 18:24:46', '2021-09-07 18:24:46', 5, 2, 1, '0', '5H82JURCNGL', '500', '0', '500', '0', '1', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (3, '2021-09-07 18:28:55', '2021-09-07 18:28:55', 6, 2, 1, '0', 'BAU9WCTNX60', '500', '0', '500', '0', '1', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');


#
# TABLE STRUCTURE FOR: mlm_invoicedetail
#

DROP TABLE IF EXISTS `mlm_invoicedetail`;

CREATE TABLE `mlm_invoicedetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `orderno` varchar(50) NOT NULL,
  `ordertype` enum('SP','SR','FP','FR','FMP','FMR','MP','KIT','KITR','PD','PDR','VP') NOT NULL,
  `productid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `mrp` float NOT NULL,
  `dp` float NOT NULL,
  `fdp` float NOT NULL,
  `bv` float NOT NULL,
  `pv` float NOT NULL,
  `sgstper` float NOT NULL,
  `sgst` float NOT NULL,
  `cgstper` float NOT NULL,
  `cgst` float NOT NULL,
  `igstper` float NOT NULL,
  `igst` float NOT NULL,
  `totalmrp` float NOT NULL,
  `totaldp` float NOT NULL,
  `totalfdp` float NOT NULL,
  `status` enum('0','1','2','3','4','5','6','7','8','9') NOT NULL COMMENT '0:pending,1:accept,2:reject,3:request,4:dispatch,5:delivery,6:cancel,7:return pending,8:return accept,9:return reject  ',
  `updateby` int(11) NOT NULL,
  `updatedate` datetime NOT NULL,
  `rndsession` varchar(100) NOT NULL,
  `kitid` int(11) NOT NULL,
  `deliverycharge` float NOT NULL,
  `invoicepaymentid` int(11) NOT NULL,
  `storedp` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_invoicedetail` (`id`, `entrydate`, `userid`, `orderid`, `orderno`, `ordertype`, `productid`, `qty`, `mrp`, `dp`, `fdp`, `bv`, `pv`, `sgstper`, `sgst`, `cgstper`, `cgst`, `igstper`, `igst`, `totalmrp`, `totaldp`, `totalfdp`, `status`, `updateby`, `updatedate`, `rndsession`, `kitid`, `deliverycharge`, `invoicepaymentid`, `storedp`) VALUES (1, '2021-09-07 11:46:16', 0, 1, '513709', 'MP', 1, 1, '0', '500', '0', '0', '0', '2.5', '11.9048', '2.5', '11.9048', '5', '23.8095', '0', '500', '0', '4', 2, '2021-09-07 15:42:43', '', 0, '0', 0, '500');
INSERT INTO `mlm_invoicedetail` (`id`, `entrydate`, `userid`, `orderid`, `orderno`, `ordertype`, `productid`, `qty`, `mrp`, `dp`, `fdp`, `bv`, `pv`, `sgstper`, `sgst`, `cgstper`, `cgst`, `igstper`, `igst`, `totalmrp`, `totaldp`, `totalfdp`, `status`, `updateby`, `updatedate`, `rndsession`, `kitid`, `deliverycharge`, `invoicepaymentid`, `storedp`) VALUES (2, '2021-09-07 13:03:53', 0, 2, '675132', 'MP', 1, 1, '0', '500', '0', '0', '0', '2.5', '11.9048', '2.5', '11.9048', '5', '23.8095', '0', '500', '0', '4', 2, '2021-09-07 13:04:39', '', 0, '0', 0, '500');
INSERT INTO `mlm_invoicedetail` (`id`, `entrydate`, `userid`, `orderid`, `orderno`, `ordertype`, `productid`, `qty`, `mrp`, `dp`, `fdp`, `bv`, `pv`, `sgstper`, `sgst`, `cgstper`, `cgst`, `igstper`, `igst`, `totalmrp`, `totaldp`, `totalfdp`, `status`, `updateby`, `updatedate`, `rndsession`, `kitid`, `deliverycharge`, `invoicepaymentid`, `storedp`) VALUES (3, '2021-09-07 13:10:12', 0, 3, '056893', 'MP', 1, 1, '0', '500', '0', '0', '0', '2.5', '11.9048', '2.5', '11.9048', '5', '23.8095', '0', '500', '0', '1', 0, '0000-00-00 00:00:00', '', 0, '0', 0, '500');
INSERT INTO `mlm_invoicedetail` (`id`, `entrydate`, `userid`, `orderid`, `orderno`, `ordertype`, `productid`, `qty`, `mrp`, `dp`, `fdp`, `bv`, `pv`, `sgstper`, `sgst`, `cgstper`, `cgst`, `igstper`, `igst`, `totalmrp`, `totaldp`, `totalfdp`, `status`, `updateby`, `updatedate`, `rndsession`, `kitid`, `deliverycharge`, `invoicepaymentid`, `storedp`) VALUES (4, '2021-09-07 15:29:31', 0, 4, '421509', 'MP', 1, 1, '0', '500', '0', '0', '0', '2.5', '11.9048', '2.5', '11.9048', '5', '23.8095', '0', '500', '0', '1', 0, '0000-00-00 00:00:00', '', 0, '0', 0, '500');
INSERT INTO `mlm_invoicedetail` (`id`, `entrydate`, `userid`, `orderid`, `orderno`, `ordertype`, `productid`, `qty`, `mrp`, `dp`, `fdp`, `bv`, `pv`, `sgstper`, `sgst`, `cgstper`, `cgst`, `igstper`, `igst`, `totalmrp`, `totaldp`, `totalfdp`, `status`, `updateby`, `updatedate`, `rndsession`, `kitid`, `deliverycharge`, `invoicepaymentid`, `storedp`) VALUES (5, '2021-09-07 15:29:31', 0, 4, '421509', 'MP', 2, 1, '0', '500', '0', '0', '0', '2.5', '11.9048', '2.5', '11.9048', '5', '23.8095', '0', '500', '0', '1', 0, '0000-00-00 00:00:00', '', 0, '0', 0, '500');
INSERT INTO `mlm_invoicedetail` (`id`, `entrydate`, `userid`, `orderid`, `orderno`, `ordertype`, `productid`, `qty`, `mrp`, `dp`, `fdp`, `bv`, `pv`, `sgstper`, `sgst`, `cgstper`, `cgst`, `igstper`, `igst`, `totalmrp`, `totaldp`, `totalfdp`, `status`, `updateby`, `updatedate`, `rndsession`, `kitid`, `deliverycharge`, `invoicepaymentid`, `storedp`) VALUES (6, '2021-09-07 18:24:46', 0, 5, '890476', 'MP', 2, 1, '0', '500', '0', '0', '0', '2.5', '11.9048', '2.5', '11.9048', '5', '23.8095', '0', '500', '0', '1', 0, '0000-00-00 00:00:00', '', 0, '0', 0, '500');
INSERT INTO `mlm_invoicedetail` (`id`, `entrydate`, `userid`, `orderid`, `orderno`, `ordertype`, `productid`, `qty`, `mrp`, `dp`, `fdp`, `bv`, `pv`, `sgstper`, `sgst`, `cgstper`, `cgst`, `igstper`, `igst`, `totalmrp`, `totaldp`, `totalfdp`, `status`, `updateby`, `updatedate`, `rndsession`, `kitid`, `deliverycharge`, `invoicepaymentid`, `storedp`) VALUES (7, '2021-09-07 18:28:55', 0, 6, '120568', 'MP', 1, 1, '0', '500', '0', '0', '0', '2.5', '11.9048', '2.5', '11.9048', '5', '23.8095', '0', '500', '0', '1', 0, '0000-00-00 00:00:00', '', 0, '0', 0, '500');


#
# TABLE STRUCTURE FOR: mlm_invoicemaster
#

DROP TABLE IF EXISTS `mlm_invoicemaster`;

CREATE TABLE `mlm_invoicemaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `ordertype` enum('SP','SR','FP','FR','FMP','FMR','MP','KIT','KITR','PD','PDR','VP') NOT NULL,
  `qty` int(11) NOT NULL,
  `orderby` int(11) NOT NULL COMMENT 'userid,receiver',
  `orderfrom` int(11) NOT NULL,
  `invoiceno` varchar(50) NOT NULL,
  `invoiceserial` varchar(100) NOT NULL,
  `invoicedate` datetime DEFAULT NULL,
  `activepurchase` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=no 1=yes',
  `mrp` float NOT NULL,
  `dp` float NOT NULL,
  `bv` float NOT NULL,
  `pv` float NOT NULL,
  `addedby` int(11) NOT NULL,
  `status` enum('0','1','2','3','4','5','6','7','8','9') NOT NULL COMMENT '0:pending,1:accept,2:reject,3:request,4:dispatch,5:delivery,6:cancel,7:return pending,8:return accept,9:return  reject ',
  `updateby` int(11) NOT NULL,
  `updatedate` datetime NOT NULL,
  `fdp` float NOT NULL,
  `sgst` float NOT NULL,
  `cgst` float NOT NULL,
  `igst` float NOT NULL,
  `netamount` float NOT NULL,
  `deliverycharge` int(11) NOT NULL,
  `interstate` enum('0','1') NOT NULL COMMENT '0:false,1:true',
  `paymentmode` enum('0','1','2','3','4','5','6','7') NOT NULL COMMENT '0:Cash,1:DD/Cheque,2:Neft/RTGS,3:repurchase wallet,4:DC,5:CC,6:net banking,7:online payment',
  `transactionno` varchar(100) NOT NULL,
  `proof` text NOT NULL,
  `paymentstatus` enum('paid','unpaid') NOT NULL,
  `walletuse` enum('no','yes') NOT NULL,
  `ewalletamount` float NOT NULL,
  `remaingamount` float NOT NULL,
  `req` enum('no','yes') NOT NULL,
  `kit` enum('no','yes') NOT NULL,
  `discount` float NOT NULL,
  `address` text NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `shipping` float NOT NULL,
  `email` varchar(100) NOT NULL,
  `pdfpath` text NOT NULL,
  `pdfupload` enum('no','yes') NOT NULL,
  `delivarymode` varchar(100) NOT NULL,
  `remark` text NOT NULL,
  `sremark` text NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `returndate` datetime NOT NULL,
  `incomestatus` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:pending,1:done',
  `canceldate` datetime NOT NULL,
  `returnacceptdate` datetime NOT NULL,
  `returnrejectdate` datetime NOT NULL,
  `incomedate` datetime NOT NULL,
  `firstorder` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:false,1:true',
  `transactionid` text NOT NULL,
  `transactionstatus` text NOT NULL,
  `transactionmsg` text NOT NULL,
  `paymentresponse` text NOT NULL,
  `docketno` varchar(100) NOT NULL,
  `couriername` varchar(100) NOT NULL,
  `deliveryremarks` text NOT NULL,
  `storedp` float NOT NULL,
  `activeid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_invoicemaster` (`id`, `entrydate`, `ordertype`, `qty`, `orderby`, `orderfrom`, `invoiceno`, `invoiceserial`, `invoicedate`, `activepurchase`, `mrp`, `dp`, `bv`, `pv`, `addedby`, `status`, `updateby`, `updatedate`, `fdp`, `sgst`, `cgst`, `igst`, `netamount`, `deliverycharge`, `interstate`, `paymentmode`, `transactionno`, `proof`, `paymentstatus`, `walletuse`, `ewalletamount`, `remaingamount`, `req`, `kit`, `discount`, `address`, `pincode`, `city`, `state`, `shipping`, `email`, `pdfpath`, `pdfupload`, `delivarymode`, `remark`, `sremark`, `mobile`, `name`, `returndate`, `incomestatus`, `canceldate`, `returnacceptdate`, `returnrejectdate`, `incomedate`, `firstorder`, `transactionid`, `transactionstatus`, `transactionmsg`, `paymentresponse`, `docketno`, `couriername`, `deliveryremarks`, `storedp`, `activeid`) VALUES (1, '2021-09-07 11:46:16', 'MP', 1, 2, 0, '513709', '2021-22/1', '2021-09-07 15:42:43', '1', '0', '500', '0', '0', 1, '4', 2, '2021-09-07 15:42:43', '0', '11.9048', '11.9048', '23.8095', '500', 0, '1', '4', 'ANOFV3GWM4E', '', 'paid', 'no', '0', '0', 'yes', 'no', '0', 'sdfsdfsd', '364005', '318', '4', '0', '', '', 'no', '', 'Activation Product', '', '8521478520', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '', '', '', 'asdsad', 'asas', '<p>asdasd</p>\r\n\r\n<p>&nbsp;</p>\r\n', '500', 1);
INSERT INTO `mlm_invoicemaster` (`id`, `entrydate`, `ordertype`, `qty`, `orderby`, `orderfrom`, `invoiceno`, `invoiceserial`, `invoicedate`, `activepurchase`, `mrp`, `dp`, `bv`, `pv`, `addedby`, `status`, `updateby`, `updatedate`, `fdp`, `sgst`, `cgst`, `igst`, `netamount`, `deliverycharge`, `interstate`, `paymentmode`, `transactionno`, `proof`, `paymentstatus`, `walletuse`, `ewalletamount`, `remaingamount`, `req`, `kit`, `discount`, `address`, `pincode`, `city`, `state`, `shipping`, `email`, `pdfpath`, `pdfupload`, `delivarymode`, `remark`, `sremark`, `mobile`, `name`, `returndate`, `incomestatus`, `canceldate`, `returnacceptdate`, `returnrejectdate`, `incomedate`, `firstorder`, `transactionid`, `transactionstatus`, `transactionmsg`, `paymentresponse`, `docketno`, `couriername`, `deliveryremarks`, `storedp`, `activeid`) VALUES (2, '2021-09-07 13:03:53', 'MP', 1, 1, 0, '675132', '2021-22/2', '2021-09-07 13:04:39', '0', '0', '500', '0', '0', 1, '4', 2, '2021-09-07 13:04:39', '0', '11.9048', '11.9048', '23.8095', '500', 0, '1', '4', '', '', 'paid', 'yes', '500', '0', 'yes', 'no', '0', 'sadasd', '364005', '10', '2', '0', '', '', 'no', '', '', '', '8521479630', 'Company ID', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '', '', '', 'dsdf454', 'Blue Dart', '<p>sdfsdf564564</p>\r\n\r\n<p>&nbsp;</p>\r\n', '500', 0);
INSERT INTO `mlm_invoicemaster` (`id`, `entrydate`, `ordertype`, `qty`, `orderby`, `orderfrom`, `invoiceno`, `invoiceserial`, `invoicedate`, `activepurchase`, `mrp`, `dp`, `bv`, `pv`, `addedby`, `status`, `updateby`, `updatedate`, `fdp`, `sgst`, `cgst`, `igst`, `netamount`, `deliverycharge`, `interstate`, `paymentmode`, `transactionno`, `proof`, `paymentstatus`, `walletuse`, `ewalletamount`, `remaingamount`, `req`, `kit`, `discount`, `address`, `pincode`, `city`, `state`, `shipping`, `email`, `pdfpath`, `pdfupload`, `delivarymode`, `remark`, `sremark`, `mobile`, `name`, `returndate`, `incomestatus`, `canceldate`, `returnacceptdate`, `returnrejectdate`, `incomedate`, `firstorder`, `transactionid`, `transactionstatus`, `transactionmsg`, `paymentresponse`, `docketno`, `couriername`, `deliveryremarks`, `storedp`, `activeid`) VALUES (3, '2021-09-07 13:10:12', 'MP', 1, 1, 0, '056893', '2021-22/3', '2021-09-07 00:00:00', '0', '0', '500', '0', '0', 1, '1', 1, '2021-09-07 13:10:12', '0', '11.9048', '11.9048', '23.8095', '500', 0, '1', '4', '', '', 'paid', 'yes', '500', '0', 'yes', 'no', '0', 'sadasd', '364005', '10', '2', '0', '', '', 'no', '', '', '', '8521479630', 'Company ID', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '', '', '', '', '', '', '500', 0);
INSERT INTO `mlm_invoicemaster` (`id`, `entrydate`, `ordertype`, `qty`, `orderby`, `orderfrom`, `invoiceno`, `invoiceserial`, `invoicedate`, `activepurchase`, `mrp`, `dp`, `bv`, `pv`, `addedby`, `status`, `updateby`, `updatedate`, `fdp`, `sgst`, `cgst`, `igst`, `netamount`, `deliverycharge`, `interstate`, `paymentmode`, `transactionno`, `proof`, `paymentstatus`, `walletuse`, `ewalletamount`, `remaingamount`, `req`, `kit`, `discount`, `address`, `pincode`, `city`, `state`, `shipping`, `email`, `pdfpath`, `pdfupload`, `delivarymode`, `remark`, `sremark`, `mobile`, `name`, `returndate`, `incomestatus`, `canceldate`, `returnacceptdate`, `returnrejectdate`, `incomedate`, `firstorder`, `transactionid`, `transactionstatus`, `transactionmsg`, `paymentresponse`, `docketno`, `couriername`, `deliveryremarks`, `storedp`, `activeid`) VALUES (4, '2021-09-07 15:29:31', 'MP', 2, 2, 0, '421509', '2021-22/4', '2021-09-07 00:00:00', '0', '0', '1000', '0', '0', 2, '1', 2, '2021-09-07 15:29:31', '0', '23.8095', '23.8095', '47.619', '1000', 0, '1', '4', '', '', 'paid', 'yes', '1000', '0', 'yes', 'no', '0', 'sdfsdfsd', '364005', '318', '4', '0', '', '', 'no', '', '', '', '8521478520', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '', '', '', '', '', '', '1000', 0);
INSERT INTO `mlm_invoicemaster` (`id`, `entrydate`, `ordertype`, `qty`, `orderby`, `orderfrom`, `invoiceno`, `invoiceserial`, `invoicedate`, `activepurchase`, `mrp`, `dp`, `bv`, `pv`, `addedby`, `status`, `updateby`, `updatedate`, `fdp`, `sgst`, `cgst`, `igst`, `netamount`, `deliverycharge`, `interstate`, `paymentmode`, `transactionno`, `proof`, `paymentstatus`, `walletuse`, `ewalletamount`, `remaingamount`, `req`, `kit`, `discount`, `address`, `pincode`, `city`, `state`, `shipping`, `email`, `pdfpath`, `pdfupload`, `delivarymode`, `remark`, `sremark`, `mobile`, `name`, `returndate`, `incomestatus`, `canceldate`, `returnacceptdate`, `returnrejectdate`, `incomedate`, `firstorder`, `transactionid`, `transactionstatus`, `transactionmsg`, `paymentresponse`, `docketno`, `couriername`, `deliveryremarks`, `storedp`, `activeid`) VALUES (5, '2021-09-07 18:24:46', 'MP', 1, 5, 0, '890476', '2021-22/5', '2021-09-07 00:00:00', '1', '0', '500', '0', '0', 2, '1', 2, '2021-09-07 18:24:46', '0', '11.9048', '11.9048', '23.8095', '500', 0, '1', '4', '5H82JURCNGL', '', 'paid', 'no', '0', '0', 'yes', 'no', '0', 'asdasdasd', '364005', '301', '3', '0', '', '', 'no', '', 'Activation Product', '', '8690311818', 'harshit', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '', '', '', '', '', '', '500', 2);
INSERT INTO `mlm_invoicemaster` (`id`, `entrydate`, `ordertype`, `qty`, `orderby`, `orderfrom`, `invoiceno`, `invoiceserial`, `invoicedate`, `activepurchase`, `mrp`, `dp`, `bv`, `pv`, `addedby`, `status`, `updateby`, `updatedate`, `fdp`, `sgst`, `cgst`, `igst`, `netamount`, `deliverycharge`, `interstate`, `paymentmode`, `transactionno`, `proof`, `paymentstatus`, `walletuse`, `ewalletamount`, `remaingamount`, `req`, `kit`, `discount`, `address`, `pincode`, `city`, `state`, `shipping`, `email`, `pdfpath`, `pdfupload`, `delivarymode`, `remark`, `sremark`, `mobile`, `name`, `returndate`, `incomestatus`, `canceldate`, `returnacceptdate`, `returnrejectdate`, `incomedate`, `firstorder`, `transactionid`, `transactionstatus`, `transactionmsg`, `paymentresponse`, `docketno`, `couriername`, `deliveryremarks`, `storedp`, `activeid`) VALUES (6, '2021-09-07 18:28:55', 'MP', 1, 6, 0, '120568', '2021-22/6', '2021-09-07 00:00:00', '1', '0', '500', '0', '0', 2, '1', 2, '2021-09-07 18:28:55', '0', '11.9048', '11.9048', '23.8095', '500', 0, '1', '4', 'BAU9WCTNX60', '', 'paid', 'no', '0', '0', 'yes', 'no', '0', 'dsfsdsd', '364005', '302', '3', '0', '', '', 'no', '', 'Activation Product', '', '8555555555', '54654', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '', '', '', '', '', '', '500', 3);


#
# TABLE STRUCTURE FOR: mlm_levelincome
#

DROP TABLE IF EXISTS `mlm_levelincome`;

CREATE TABLE `mlm_levelincome` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `levelno` int(11) NOT NULL,
  `structurelevel` int(11) NOT NULL,
  `perc` float NOT NULL,
  `amount` float NOT NULL,
  `tds` float NOT NULL,
  `netamount` float NOT NULL,
  `refid` int(11) NOT NULL,
  `type` enum('0','1') NOT NULL DEFAULT '0' COMMENT '1: Upline Distribution, 0: Downline Distribution',
  `admincharge` float NOT NULL,
  `repurchaseamount` float NOT NULL,
  `selfpurchase` float NOT NULL,
  `status` enum('0','1','3') NOT NULL DEFAULT '0' COMMENT '0=Pending 1=Accept 3=Reject',
  `remark` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entrydate` (`entrydate`),
  KEY `netamount` (`netamount`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_levelincome` (`id`, `entrydate`, `userid`, `fromid`, `levelno`, `structurelevel`, `perc`, `amount`, `tds`, `netamount`, `refid`, `type`, `admincharge`, `repurchaseamount`, `selfpurchase`, `status`, `remark`) VALUES (1, '2021-09-07 11:46:16', 1, 2, 1, 0, '13', '65', '0', '65', 1, '0', '0', '0', '0', '0', '');
INSERT INTO `mlm_levelincome` (`id`, `entrydate`, `userid`, `fromid`, `levelno`, `structurelevel`, `perc`, `amount`, `tds`, `netamount`, `refid`, `type`, `admincharge`, `repurchaseamount`, `selfpurchase`, `status`, `remark`) VALUES (2, '2021-09-07 18:24:46', 2, 5, 1, 0, '13', '65', '0', '65', 2, '0', '0', '0', '0', '0', '');
INSERT INTO `mlm_levelincome` (`id`, `entrydate`, `userid`, `fromid`, `levelno`, `structurelevel`, `perc`, `amount`, `tds`, `netamount`, `refid`, `type`, `admincharge`, `repurchaseamount`, `selfpurchase`, `status`, `remark`) VALUES (3, '2021-09-07 18:24:46', 1, 5, 2, 0, '5', '25', '0', '25', 2, '0', '0', '0', '0', '0', '');
INSERT INTO `mlm_levelincome` (`id`, `entrydate`, `userid`, `fromid`, `levelno`, `structurelevel`, `perc`, `amount`, `tds`, `netamount`, `refid`, `type`, `admincharge`, `repurchaseamount`, `selfpurchase`, `status`, `remark`) VALUES (4, '2021-09-07 18:28:55', 2, 6, 1, 0, '13', '65', '0', '65', 3, '0', '0', '0', '0', '0', '');
INSERT INTO `mlm_levelincome` (`id`, `entrydate`, `userid`, `fromid`, `levelno`, `structurelevel`, `perc`, `amount`, `tds`, `netamount`, `refid`, `type`, `admincharge`, `repurchaseamount`, `selfpurchase`, `status`, `remark`) VALUES (5, '2021-09-07 18:28:55', 1, 6, 2, 0, '5', '25', '0', '25', 3, '0', '0', '0', '0', '0', '');


#
# TABLE STRUCTURE FOR: mlm_packagesetting
#

DROP TABLE IF EXISTS `mlm_packagesetting`;

CREATE TABLE `mlm_packagesetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `packagename` varchar(100) NOT NULL,
  `activestatus` enum('0','1','2','3') NOT NULL DEFAULT '1' COMMENT '0: Free, 1: Active, 2: Only For Topup 3 : Purchase',
  `priority` int(11) NOT NULL,
  `mrp` float NOT NULL,
  `tax` float NOT NULL,
  `netmrp` float NOT NULL,
  `lockPackage` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:no,1:yes',
  `editFlag` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0:no,1:yes',
  `pv` float NOT NULL,
  `bv` float NOT NULL,
  `binaryperc` float NOT NULL,
  `capping` float NOT NULL,
  `shoppingbal` float NOT NULL,
  `roi` float NOT NULL,
  `roidays` int(11) NOT NULL,
  `roiinterval` int(11) NOT NULL,
  `directper` float NOT NULL,
  `directamt` float NOT NULL,
  `total` int(11) NOT NULL,
  `used` int(11) NOT NULL,
  `unused` int(11) NOT NULL,
  `addedby` int(11) NOT NULL,
  `view` enum('view','close') NOT NULL,
  `updatedate` datetime NOT NULL,
  `updateby` int(11) NOT NULL,
  `kitid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_packagesetting` (`id`, `entrydate`, `packagename`, `activestatus`, `priority`, `mrp`, `tax`, `netmrp`, `lockPackage`, `editFlag`, `pv`, `bv`, `binaryperc`, `capping`, `shoppingbal`, `roi`, `roidays`, `roiinterval`, `directper`, `directamt`, `total`, `used`, `unused`, `addedby`, `view`, `updatedate`, `updateby`, `kitid`) VALUES (1, '2018-09-17 00:00:00', 'Active Package', '1', 1, '500', '0', '500', '0', '1', '1', '0', '0', '0', '0', '0', 0, 0, '8', '0', 0, 0, 0, 0, 'view', '2019-09-03 15:59:27', 0, 0);


#
# TABLE STRUCTURE FOR: mlm_productmaster
#

DROP TABLE IF EXISTS `mlm_productmaster`;

CREATE TABLE `mlm_productmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `entrydate` datetime NOT NULL,
  `productname` varchar(255) NOT NULL,
  `subtitle` text NOT NULL,
  `packagecode` int(11) NOT NULL,
  `model` varchar(50) NOT NULL,
  `kit` enum('yes','no') NOT NULL DEFAULT 'no',
  `mrp` float NOT NULL,
  `dp` float NOT NULL,
  `fdp` float NOT NULL,
  `bv` float NOT NULL,
  `pv` float NOT NULL,
  `hsnid` int(11) NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0 : view 1: hide 2: delete',
  `profile` text NOT NULL,
  `netmrp` float NOT NULL,
  `netdp` float NOT NULL,
  `netfdp` float NOT NULL,
  `sgstper` float NOT NULL,
  `sgst` float NOT NULL,
  `discount` float NOT NULL,
  `cgstper` float NOT NULL,
  `cgst` float NOT NULL,
  `igstper` float NOT NULL,
  `igst` float NOT NULL,
  `openingstock` int(11) NOT NULL,
  `description` text NOT NULL,
  `addedby` int(11) NOT NULL,
  `lastupdatedate` datetime NOT NULL,
  `deliverycharge` float NOT NULL,
  `onlyadmin` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=All 1=Admin',
  `rentamount` float NOT NULL,
  `timerent` int(11) NOT NULL COMMENT 'In Month',
  `renewal` float NOT NULL,
  `timerenewal` int(11) NOT NULL COMMENT 'In Month',
  `shoppeamount` float NOT NULL,
  `timeshopee` int(11) NOT NULL COMMENT 'In Month',
  `activationview` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=view 1=No',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_productmaster` (`id`, `category`, `entrydate`, `productname`, `subtitle`, `packagecode`, `model`, `kit`, `mrp`, `dp`, `fdp`, `bv`, `pv`, `hsnid`, `status`, `profile`, `netmrp`, `netdp`, `netfdp`, `sgstper`, `sgst`, `discount`, `cgstper`, `cgst`, `igstper`, `igst`, `openingstock`, `description`, `addedby`, `lastupdatedate`, `deliverycharge`, `onlyadmin`, `rentamount`, `timerent`, `renewal`, `timerenewal`, `shoppeamount`, `timeshopee`, `activationview`) VALUES (1, 0, '2021-09-02 17:03:33', 'Agarbati', '', 0, '', 'no', '0', '500', '0', '0', '0', 1, '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 0, '', 2, '2021-09-02 17:04:51', '0', '0', '0', 0, '0', 0, '0', 0, '0');
INSERT INTO `mlm_productmaster` (`id`, `category`, `entrydate`, `productname`, `subtitle`, `packagecode`, `model`, `kit`, `mrp`, `dp`, `fdp`, `bv`, `pv`, `hsnid`, `status`, `profile`, `netmrp`, `netdp`, `netfdp`, `sgstper`, `sgst`, `discount`, `cgstper`, `cgst`, `igstper`, `igst`, `openingstock`, `description`, `addedby`, `lastupdatedate`, `deliverycharge`, `onlyadmin`, `rentamount`, `timerent`, `renewal`, `timerenewal`, `shoppeamount`, `timeshopee`, `activationview`) VALUES (2, 0, '2021-09-03 11:25:58', 'Dhup', '', 0, '', 'no', '0', '500', '0', '0', '0', 1, '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 0, '', 2, '0000-00-00 00:00:00', '0', '0', '0', 0, '0', 0, '0', 0, '0');


#
# TABLE STRUCTURE FOR: mlm_walletmaster
#

DROP TABLE IF EXISTS `mlm_walletmaster`;

CREATE TABLE `mlm_walletmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `amount` float NOT NULL,
  `remark` text NOT NULL,
  `status` enum('0','1','2') NOT NULL COMMENT '0:pending 1:Accept 2:Reject',
  `statusdate` datetime NOT NULL,
  `statusby` int(11) NOT NULL,
  `proof` text NOT NULL,
  `accnumber` varchar(50) NOT NULL,
  `acctype` varchar(50) NOT NULL,
  `reqtype` enum('0','1','2') NOT NULL COMMENT '0: Added By Admin 1: Request 2: Transfer',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_walletmaster` (`id`, `entrydate`, `userid`, `fromid`, `amount`, `remark`, `status`, `statusdate`, `statusby`, `proof`, `accnumber`, `acctype`, `reqtype`) VALUES (1, '2021-09-07 13:00:19', 1, 3, '100', '', '1', '0000-00-00 00:00:00', 0, '', '', '', '2');
INSERT INTO `mlm_walletmaster` (`id`, `entrydate`, `userid`, `fromid`, `amount`, `remark`, `status`, `statusdate`, `statusby`, `proof`, `accnumber`, `acctype`, `reqtype`) VALUES (2, '2021-09-07 17:23:27', 1, 2, '150', '', '1', '0000-00-00 00:00:00', 0, '', '', '', '2');
INSERT INTO `mlm_walletmaster` (`id`, `entrydate`, `userid`, `fromid`, `amount`, `remark`, `status`, `statusdate`, `statusby`, `proof`, `accnumber`, `acctype`, `reqtype`) VALUES (3, '2021-09-07 17:26:14', 1, 2, '160', '', '1', '0000-00-00 00:00:00', 0, '', '', '', '2');


#
# TABLE STRUCTURE FOR: mlm_walletorder
#

DROP TABLE IF EXISTS `mlm_walletorder`;

CREATE TABLE `mlm_walletorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `type` enum('0','1') NOT NULL COMMENT '0:Credit,1:Debit',
  `reqtype` enum('0','1') NOT NULL COMMENT '0:Admin,1:Member',
  `amount` int(11) NOT NULL,
  `status` enum('0','1','2','3','4','5') NOT NULL COMMENT '0:Pending,1:Accept,2:Reject,3:pending payment,4:accept payment,5:reject payment',
  `statusdate` datetime DEFAULT NULL,
  `statusby` int(11) NOT NULL,
  `proof` text NOT NULL,
  `paymentmode` enum('0','1','2','3') DEFAULT NULL COMMENT '0:cash,1:NEFT,2:cheque	,3:online payment',
  `remarks` varchar(100) NOT NULL,
  `transactionId` varchar(50) NOT NULL,
  `response` text NOT NULL,
  `onlinepaymentamount` float NOT NULL,
  `paymentgatewayid` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`) VALUES (1, '2021-09-07 12:59:32', 1, '0', '1', 1000, '1', '2021-09-07 12:59:48', 2, '1630999772.jpg', '1', '', 'zdfzd', '', '0', '');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`) VALUES (2, '2021-09-07 13:00:45', 1, '0', '0', 1000, '1', '2021-09-07 13:00:45', 2, '', NULL, '', '', '', '0', '');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`) VALUES (3, '2021-09-07 13:01:16', 1, '1', '0', 1000, '1', '2021-09-07 13:01:16', 2, '', NULL, '', '', '', '0', '');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`) VALUES (4, '2021-09-07 13:01:31', 1, '1', '0', 2000, '1', '2021-09-07 13:01:31', 2, '', NULL, '', '', '', '0', '');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`) VALUES (5, '2021-09-07 13:01:58', 1, '0', '0', 2100, '1', '2021-09-07 13:01:58', 2, '', NULL, '', '', '', '0', '');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`) VALUES (6, '2021-09-07 15:29:23', 2, '0', '0', 1000, '1', '2021-09-07 15:29:23', 2, '', NULL, '', '', '', '0', '');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`) VALUES (7, '2021-09-07 17:22:59', 1, '0', '0', 1000, '1', '2021-09-07 17:22:59', 2, '', NULL, '', '', '', '0', '');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`) VALUES (8, '2021-09-07 17:55:59', 2, '0', '0', 10000, '1', '2021-09-07 17:55:59', 2, '', NULL, '', '', '', '0', '');


#
# TABLE STRUCTURE FOR: mlm_gstmaster
#

DROP TABLE IF EXISTS `mlm_gstmaster`;

CREATE TABLE `mlm_gstmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `hsncode` varchar(50) NOT NULL,
  `sgst` float NOT NULL,
  `cgst` float NOT NULL,
  `igst` float NOT NULL,
  `addedby` int(11) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0:hide,1:show',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_gstmaster` (`id`, `entrydate`, `updatedate`, `hsncode`, `sgst`, `cgst`, `igst`, `addedby`, `status`) VALUES (1, '2021-09-02 17:02:20', '0000-00-00 00:00:00', '1561', '2.5', '2.5', '5', 2, '1');


#
# TABLE STRUCTURE FOR: mlm_repurchasedesignation
#

DROP TABLE IF EXISTS `mlm_repurchasedesignation`;

CREATE TABLE `mlm_repurchasedesignation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `wallet` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_repurchasedesignation` (`id`, `entrydate`, `userid`, `rid`, `wallet`) VALUES (1, '2021-09-07 19:04:45', 1, 1, 2000);
INSERT INTO `mlm_repurchasedesignation` (`id`, `entrydate`, `userid`, `rid`, `wallet`) VALUES (2, '2021-09-07 19:04:45', 2, 1, 2000);
INSERT INTO `mlm_repurchasedesignation` (`id`, `entrydate`, `userid`, `rid`, `wallet`) VALUES (3, '2021-09-07 19:04:45', 6, 1, 2000);
INSERT INTO `mlm_repurchasedesignation` (`id`, `entrydate`, `userid`, `rid`, `wallet`) VALUES (4, '2021-09-07 19:04:45', 1, 2, 6000);
INSERT INTO `mlm_repurchasedesignation` (`id`, `entrydate`, `userid`, `rid`, `wallet`) VALUES (5, '2021-09-07 19:04:45', 2, 2, 6000);


#
# TABLE STRUCTURE FOR: mlm_levelmaster
#

DROP TABLE IF EXISTS `mlm_levelmaster`;

CREATE TABLE `mlm_levelmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `levelno` int(11) NOT NULL,
  `per` float NOT NULL,
  `amount` float NOT NULL,
  `pcode` int(11) NOT NULL,
  `reserve` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`) VALUES (1, 1, '13', '65', 0, '0');
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`) VALUES (2, 2, '5', '25', 0, '0');
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`) VALUES (3, 3, '3', '15', 0, '0');
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`) VALUES (4, 4, '2', '10', 0, '0');
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`) VALUES (5, 5, '1', '5', 0, '0');
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`) VALUES (6, 6, '1', '5', 0, '0');
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`) VALUES (7, 7, '1', '5', 0, '0');
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`) VALUES (8, 8, '1', '5', 0, '0');
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`) VALUES (9, 9, '1', '5', 0, '0');
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`) VALUES (10, 10, '2', '10', 0, '0');


#
# TABLE STRUCTURE FOR: mlm_pinmaster
#

DROP TABLE IF EXISTS `mlm_pinmaster`;

CREATE TABLE `mlm_pinmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `pinno` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `statusdate` datetime NOT NULL,
  `usedby` int(11) NOT NULL,
  `refid` int(11) NOT NULL,
  `packagecode` int(11) NOT NULL,
  `orderby` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:memberid,1:franchisee',
  `deleteid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pinno` (`pinno`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (1, '2021-09-07 11:43:41', 1, 'ANOFV3GWM4E', 1, '2021-09-07 11:46:16', 2, 1, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (2, '2021-09-07 11:43:41', 1, 'RHKE6SZ43NO', 0, '0000-00-00 00:00:00', 0, 1, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (3, '2021-09-07 11:43:41', 1, '08PYC7T5LOE', 0, '0000-00-00 00:00:00', 0, 1, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (4, '2021-09-07 11:43:41', 1, 'JYBUGHVMQEK', 0, '0000-00-00 00:00:00', 0, 1, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (5, '2021-09-07 11:43:41', 1, 'MU9G5FE02T8', 0, '0000-00-00 00:00:00', 0, 1, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (6, '2021-09-07 11:43:41', 1, '9T2J5A3V6ZF', 0, '0000-00-00 00:00:00', 0, 1, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (7, '2021-09-07 11:43:41', 1, 'MP3HSFQKO78', 0, '0000-00-00 00:00:00', 0, 1, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (8, '2021-09-07 11:43:41', 1, 'WLSIUTH2QP9', 0, '0000-00-00 00:00:00', 0, 1, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (9, '2021-09-07 11:43:41', 1, 'S8FMP74XJ2B', 0, '0000-00-00 00:00:00', 0, 1, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (10, '2021-09-07 11:43:41', 1, 'NFXDMQ8WY96', 0, '0000-00-00 00:00:00', 0, 1, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (11, '2021-09-07 12:40:16', 1, '0NJ3HC2F1KQ', 0, '0000-00-00 00:00:00', 0, 2, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (12, '2021-09-07 18:03:43', 2, '5H82JURCNGL', 1, '2021-09-07 18:24:46', 5, 3, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (13, '2021-09-07 18:03:43', 2, 'BAU9WCTNX60', 1, '2021-09-07 18:28:55', 6, 3, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (14, '2021-09-07 18:03:43', 2, 'VG519KQE0J3', 0, '0000-00-00 00:00:00', 0, 3, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (15, '2021-09-07 18:03:43', 2, 'NK3L7JHBADZ', 0, '0000-00-00 00:00:00', 0, 3, 1, '0', 0);
INSERT INTO `mlm_pinmaster` (`id`, `entrydate`, `userid`, `pinno`, `status`, `statusdate`, `usedby`, `refid`, `packagecode`, `orderby`, `deleteid`) VALUES (16, '2021-09-07 18:03:43', 2, 'QA0TVLS4CWD', 0, '0000-00-00 00:00:00', 0, 3, 1, '0', 0);


#
# TABLE STRUCTURE FOR: mlm_pintransaction
#

DROP TABLE IF EXISTS `mlm_pintransaction`;

CREATE TABLE `mlm_pintransaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `pinid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` varchar(50) NOT NULL,
  `type` enum('0','1','2','3','4','5') NOT NULL DEFAULT '0' COMMENT '0:Allocation,1:Member To Member Pin Transfer,2:Used for register,3:Used For Activation,4:Franchisee To Member Pin Transfer 5=Pin Generated',
  `refid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (1, '2021-09-07 11:43:41', 1, 1, '2', '0', 1);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (2, '2021-09-07 11:43:41', 2, 1, '2', '0', 1);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (3, '2021-09-07 11:43:41', 3, 1, '2', '0', 1);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (4, '2021-09-07 11:43:41', 4, 1, '2', '0', 1);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (5, '2021-09-07 11:43:41', 5, 1, '2', '0', 1);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (6, '2021-09-07 11:43:41', 6, 1, '2', '0', 1);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (7, '2021-09-07 11:43:41', 7, 1, '2', '0', 1);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (8, '2021-09-07 11:43:41', 8, 1, '2', '0', 1);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (9, '2021-09-07 11:43:41', 9, 1, '2', '0', 1);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (10, '2021-09-07 11:43:41', 10, 1, '2', '0', 1);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (11, '2021-09-07 11:46:16', 1, 2, '1', '3', 0);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (12, '2021-09-07 12:40:16', 11, 1, '2', '0', 2);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (13, '2021-09-07 18:03:43', 12, 2, '2', '5', 3);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (14, '2021-09-07 18:03:43', 13, 2, '2', '5', 3);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (15, '2021-09-07 18:03:43', 14, 2, '2', '5', 3);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (16, '2021-09-07 18:03:43', 15, 2, '2', '5', 3);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (17, '2021-09-07 18:03:43', 16, 2, '2', '5', 3);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (18, '2021-09-07 18:24:46', 12, 5, '2', '3', 0);
INSERT INTO `mlm_pintransaction` (`id`, `entrydate`, `pinid`, `userid`, `fromid`, `type`, `refid`) VALUES (19, '2021-09-07 18:28:55', 13, 6, '2', '3', 0);


#
# TABLE STRUCTURE FOR: mlm_pinorder
#

DROP TABLE IF EXISTS `mlm_pinorder`;

CREATE TABLE `mlm_pinorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` varchar(50) NOT NULL,
  `type` enum('0','1','3') NOT NULL COMMENT '0:Pin Allocate,1:Pin request accepted 3:Pin Generate',
  `status` varchar(100) NOT NULL,
  `statusdate` datetime NOT NULL,
  `pincount` int(11) NOT NULL,
  `remark` text NOT NULL,
  `proof` text NOT NULL,
  `packagecode` int(11) NOT NULL,
  `orderby` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:member,1franchisee',
  `amount` float NOT NULL,
  `tds` float NOT NULL,
  `admincharge` float NOT NULL,
  `netamount` float NOT NULL,
  `generateid` int(11) NOT NULL DEFAULT '0',
  `charge` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_pinorder` (`id`, `entrydate`, `userid`, `fromid`, `type`, `status`, `statusdate`, `pincount`, `remark`, `proof`, `packagecode`, `orderby`, `amount`, `tds`, `admincharge`, `netamount`, `generateid`, `charge`) VALUES (1, '2021-09-07 11:43:41', 1, '2', '0', '1', '0000-00-00 00:00:00', 10, '', '', 1, '0', '0', '0', '0', '0', 0, '0');
INSERT INTO `mlm_pinorder` (`id`, `entrydate`, `userid`, `fromid`, `type`, `status`, `statusdate`, `pincount`, `remark`, `proof`, `packagecode`, `orderby`, `amount`, `tds`, `admincharge`, `netamount`, `generateid`, `charge`) VALUES (2, '2021-09-07 12:40:16', 1, '2', '1', '1', '0000-00-00 00:00:00', 1, 'Pin Request Accept', '', 1, '0', '0', '0', '0', '0', 0, '0');
INSERT INTO `mlm_pinorder` (`id`, `entrydate`, `userid`, `fromid`, `type`, `status`, `statusdate`, `pincount`, `remark`, `proof`, `packagecode`, `orderby`, `amount`, `tds`, `admincharge`, `netamount`, `generateid`, `charge`) VALUES (3, '2021-09-07 18:03:43', 2, '2', '3', '1', '0000-00-00 00:00:00', 5, 'Pin Generated', '', 1, '0', '2500', '0', '0', '2500', 0, '0');


#
# TABLE STRUCTURE FOR: mlm_withdrawalreq
#

DROP TABLE IF EXISTS `mlm_withdrawalreq`;

CREATE TABLE `mlm_withdrawalreq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `amount` float NOT NULL,
  `admincharge` float NOT NULL,
  `tds` float NOT NULL,
  `othercharge` float NOT NULL,
  `netamount` float NOT NULL,
  `status` enum('0','1','2') NOT NULL COMMENT '0:Pending, 1:Accept, 2: Reject',
  `statusby` varchar(100) NOT NULL,
  `statusdate` datetime NOT NULL,
  `remark` text NOT NULL,
  `bankname` text NOT NULL,
  `banktype` text,
  `bankifsc` text NOT NULL,
  `bankaccno` text NOT NULL,
  `bankbranch` text NOT NULL,
  `bankaccname` text NOT NULL,
  `joinfrom` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0:web,1:android,2:ios',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_withdrawalreq` (`id`, `entrydate`, `userid`, `amount`, `admincharge`, `tds`, `othercharge`, `netamount`, `status`, `statusby`, `statusdate`, `remark`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `joinfrom`) VALUES (1, '2021-09-08 16:01:52', 1, '8213', '164.26', '410.65', '0', '7638.09', '2', '2', '2021-09-08 16:31:51', '', 'THE ROYAL BANK OF SCOTLAND N V', 'Current', 'SBIN01234f6', '85217479630', 'ASDFG', 'ASDFG', '0');
INSERT INTO `mlm_withdrawalreq` (`id`, `entrydate`, `userid`, `amount`, `admincharge`, `tds`, `othercharge`, `netamount`, `status`, `statusby`, `statusdate`, `remark`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `joinfrom`) VALUES (2, '2021-09-08 16:32:24', 1, '8213', '164.26', '410.65', '0', '7638.09', '1', '2', '2021-09-08 16:34:54', '', 'THE ROYAL BANK OF SCOTLAND N V', 'Current', 'SBIN01234f6', '85217479630', 'ASDFG', 'ASDFG', '0');


#
# TABLE STRUCTURE FOR: mlm_repurchaseincome
#

DROP TABLE IF EXISTS `mlm_repurchaseincome`;

CREATE TABLE `mlm_repurchaseincome` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `levelno` int(11) NOT NULL,
  `mainamount` int(11) NOT NULL,
  `perc` float NOT NULL,
  `amount` float NOT NULL,
  `tds` float NOT NULL,
  `netamount` float NOT NULL,
  `refid` int(11) NOT NULL,
  `type` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:level income,1:binary income',
  `admincharge` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_repurchaseincome` (`id`, `entrydate`, `userid`, `fromid`, `levelno`, `mainamount`, `perc`, `amount`, `tds`, `netamount`, `refid`, `type`, `admincharge`) VALUES (1, '2021-09-07 15:29:31', 1, 2, 1, 1000, '10', '100', '0', '100', 4, '0', '0');



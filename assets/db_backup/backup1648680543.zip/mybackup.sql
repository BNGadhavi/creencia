#
# TABLE STRUCTURE FOR: mlm_transaction
#

DROP TABLE IF EXISTS `mlm_transaction`;

CREATE TABLE `mlm_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `status` enum('paid','unpaid') NOT NULL,
  `refid` int(11) NOT NULL,
  `remark` varchar(200) NOT NULL,
  `transtype` varchar(50) NOT NULL,
  `wallettype` varchar(50) NOT NULL,
  `netamount` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `wallettype` (`wallettype`),
  KEY `netamount` (`netamount`),
  KEY `entrydate` (`entrydate`,`userid`,`transtype`,`wallettype`,`netamount`)
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (1, '2022-03-29 21:34:49', 2, 0, 'paid', 1, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '50000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (2, '2022-03-29 21:36:28', 2, 0, 'paid', 0, 'Topup Of D876132', 'Coin Wallet', 'Coin Wallet', '-50000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (3, '2022-03-29 21:36:28', 1, 2, 'paid', 1, 'Referral Income', 'Referral Income', 'Income Wallet', '400');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (4, '2022-03-29 21:39:58', 1, 0, 'paid', 2, 'DCC Wallet Convert', 'DCC Wallet Convert', 'Coin Wallet', '4000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (5, '2022-03-29 21:39:58', 1, 0, 'paid', 2, 'DCC Wallet Convert', 'DCC Wallet Convert', 'Income Wallet', '-400');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (6, '2022-03-29 23:59:59', 1, 0, 'paid', 2, 'Level Income Generated', 'Level Income', 'Income Wallet', '4.0175');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (7, '2022-03-29 23:59:59', 2, 0, 'paid', 1, 'ROI Income Generated', 'ROI Income', 'Income Wallet', '16.07');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (8, '2022-03-30 23:59:59', 1, 0, 'paid', 2, 'Level Income Generated', 'Level Income', 'Income Wallet', '4.0175');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (9, '2022-03-30 23:59:59', 1, 0, 'paid', 4, 'Level Income Generated', 'Level Income', 'Income Wallet', '4.0175');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (10, '2022-03-30 23:59:59', 2, 0, 'paid', 1, 'ROI Income Generated', 'ROI Income', 'Income Wallet', '16.07');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (11, '2022-03-30 23:59:59', 2, 0, 'paid', 3, 'ROI Income Generated', 'ROI Income', 'Income Wallet', '16.07');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (12, '2022-03-31 02:05:28', 3, 0, 'paid', 2, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (13, '2022-03-31 02:05:40', 3, 0, 'paid', 0, 'Topup Of D958327', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (14, '2022-03-31 02:05:40', 2, 3, 'paid', 2, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (15, '2022-03-31 02:14:49', 4, 0, 'paid', 3, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (16, '2022-03-31 02:15:01', 4, 0, 'paid', 0, 'Topup Of D748259', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (17, '2022-03-31 02:15:01', 2, 4, 'paid', 3, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (18, '2022-03-31 02:17:41', 5, 0, 'paid', 4, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (19, '2022-03-31 02:18:04', 5, 0, 'paid', 0, 'Topup Of D147325', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (20, '2022-03-31 02:18:04', 2, 5, 'paid', 4, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (21, '2022-03-31 02:19:59', 6, 0, 'paid', 5, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (22, '2022-03-31 02:20:09', 6, 0, 'paid', 0, 'Topup Of D357894', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (23, '2022-03-31 02:20:09', 2, 6, 'paid', 5, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (24, '2022-03-31 02:22:33', 7, 0, 'paid', 6, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (25, '2022-03-31 02:24:36', 7, 0, 'paid', 0, 'Topup Of D419527', 'Coin Wallet', 'Coin Wallet', '-500000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (26, '2022-03-31 02:24:36', 2, 7, 'paid', 6, 'Referral Income', 'Referral Income', 'Income Wallet', '4000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (27, '2022-03-31 02:34:08', 8, 0, 'paid', 7, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (28, '2022-03-31 02:34:19', 8, 0, 'paid', 0, 'Topup Of D973241', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (29, '2022-03-31 02:34:19', 7, 8, 'paid', 7, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (30, '2022-03-31 02:36:24', 9, 0, 'paid', 8, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (31, '2022-03-31 02:36:32', 9, 0, 'paid', 0, 'Topup Of D371826', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (32, '2022-03-31 02:36:32', 7, 9, 'paid', 8, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (33, '2022-03-31 02:38:32', 10, 0, 'paid', 9, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (34, '2022-03-31 02:38:40', 10, 0, 'paid', 0, 'Topup Of D348716', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (35, '2022-03-31 02:38:40', 7, 10, 'paid', 9, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (36, '2022-03-31 02:41:03', 11, 0, 'paid', 10, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (37, '2022-03-31 02:41:14', 11, 0, 'paid', 0, 'Topup Of D682453', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (38, '2022-03-31 02:41:14', 7, 11, 'paid', 10, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (39, '2022-03-31 02:44:23', 12, 0, 'paid', 11, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '50000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (40, '2022-03-31 02:44:36', 12, 0, 'paid', 0, 'Topup Of D135689', 'Coin Wallet', 'Coin Wallet', '-50000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (41, '2022-03-31 02:44:36', 7, 12, 'paid', 11, 'Referral Income', 'Referral Income', 'Income Wallet', '400');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (42, '2022-03-31 03:00:37', 13, 0, 'paid', 12, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (43, '2022-03-31 03:00:47', 13, 0, 'paid', 0, 'Topup Of D498153', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (44, '2022-03-31 03:00:47', 12, 13, 'paid', 12, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (45, '2022-03-31 03:03:09', 14, 0, 'paid', 13, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (46, '2022-03-31 03:03:18', 14, 0, 'paid', 0, 'Topup Of D738246', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (47, '2022-03-31 03:03:18', 12, 14, 'paid', 13, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (48, '2022-03-31 03:05:19', 15, 0, 'paid', 14, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (49, '2022-03-31 03:05:29', 15, 0, 'paid', 0, 'Topup Of D846251', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (50, '2022-03-31 03:05:29', 12, 15, 'paid', 14, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (51, '2022-03-31 03:08:40', 16, 0, 'paid', 15, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (52, '2022-03-31 03:08:49', 16, 0, 'paid', 0, 'Topup Of D235819', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (53, '2022-03-31 03:08:49', 12, 16, 'paid', 15, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (54, '2022-03-31 03:16:31', 17, 0, 'paid', 16, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '50000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (55, '2022-03-31 03:16:41', 17, 0, 'paid', 0, 'Topup Of D428917', 'Coin Wallet', 'Coin Wallet', '-50000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (56, '2022-03-31 03:16:41', 12, 17, 'paid', 16, 'Referral Income', 'Referral Income', 'Income Wallet', '400');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (57, '2022-03-31 03:19:53', 18, 0, 'paid', 17, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (58, '2022-03-31 03:20:01', 18, 0, 'paid', 0, 'Topup Of D671428', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (59, '2022-03-31 03:20:01', 17, 18, 'paid', 17, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (60, '2022-03-31 03:21:49', 19, 0, 'paid', 18, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (61, '2022-03-31 03:21:58', 19, 0, 'paid', 0, 'Topup Of D813754', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (62, '2022-03-31 03:21:58', 17, 19, 'paid', 18, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (63, '2022-03-31 03:23:56', 20, 0, 'paid', 19, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (64, '2022-03-31 03:24:07', 20, 0, 'paid', 0, 'Topup Of D189435', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (65, '2022-03-31 03:24:07', 17, 20, 'paid', 19, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (66, '2022-03-31 03:27:05', 21, 0, 'paid', 20, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (67, '2022-03-31 03:27:17', 21, 0, 'paid', 0, 'Topup Of D678451', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (68, '2022-03-31 03:27:17', 17, 21, 'paid', 20, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (69, '2022-03-31 03:37:41', 22, 0, 'paid', 21, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '50000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (70, '2022-03-31 03:38:00', 22, 0, 'paid', 0, 'Topup Of D916254', 'Coin Wallet', 'Coin Wallet', '-50000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (71, '2022-03-31 03:38:00', 17, 22, 'paid', 21, 'Referral Income', 'Referral Income', 'Income Wallet', '400');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (72, '2022-03-31 03:41:05', 23, 0, 'paid', 22, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (73, '2022-03-31 03:41:14', 23, 0, 'paid', 0, 'Topup Of D138726', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (74, '2022-03-31 03:41:14', 22, 23, 'paid', 22, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (75, '2022-03-31 03:44:15', 24, 0, 'paid', 23, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (76, '2022-03-31 03:44:29', 24, 0, 'paid', 0, 'Topup Of D391627', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (77, '2022-03-31 03:44:29', 22, 24, 'paid', 23, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (78, '2022-03-31 03:46:27', 25, 0, 'paid', 24, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (79, '2022-03-31 03:46:37', 25, 0, 'paid', 0, 'Topup Of D175324', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (80, '2022-03-31 03:46:37', 22, 25, 'paid', 24, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (81, '2022-03-31 03:48:51', 26, 0, 'paid', 25, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (82, '2022-03-31 03:48:58', 26, 0, 'paid', 0, 'Topup Of D853941', 'Coin Wallet', 'Coin Wallet', '-500');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (83, '2022-03-31 03:48:58', 22, 26, 'paid', 25, 'Referral Income', 'Referral Income', 'Income Wallet', '4');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (84, '2022-03-31 03:51:06', 27, 0, 'paid', 26, 'Request Accepted', 'Coin Wallet', 'Coin Wallet', '1000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (85, '2022-03-31 03:51:14', 27, 0, 'paid', 0, 'Topup Of D675824', 'Coin Wallet', 'Coin Wallet', '-1000');
INSERT INTO `mlm_transaction` (`id`, `entrydate`, `userid`, `fromid`, `status`, `refid`, `remark`, `transtype`, `wallettype`, `netamount`) VALUES (86, '2022-03-31 03:51:14', 22, 27, 'paid', 26, 'Referral Income', 'Referral Income', 'Income Wallet', '8');


#
# TABLE STRUCTURE FOR: mlm_userdetail
#

DROP TABLE IF EXISTS `mlm_userdetail`;

CREATE TABLE `mlm_userdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `fname` text NOT NULL,
  `mname` text NOT NULL,
  `lname` text NOT NULL,
  `fullname` text NOT NULL,
  `dob` varchar(50) NOT NULL,
  `sex` text NOT NULL,
  `regtype` enum('0','1') NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `whatsapp` bigint(20) NOT NULL,
  `address` varchar(150) NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `country` text NOT NULL,
  `bankname` text,
  `banktype` text,
  `bankifsc` varchar(50) NOT NULL,
  `bankaccno` varchar(50) NOT NULL,
  `bankbranch` text NOT NULL,
  `bankaccname` text NOT NULL,
  `panno` varchar(15) NOT NULL,
  `pincode` varchar(15) NOT NULL,
  `nominee` varchar(100) NOT NULL,
  `nomineerel` varchar(50) DEFAULT NULL,
  `profile` text NOT NULL,
  `district` varchar(50) NOT NULL,
  `secretque` text NOT NULL,
  `secretans` text NOT NULL,
  `maritalstatus` varchar(50) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `micrcode` varchar(50) NOT NULL,
  `aadharcard` varchar(100) NOT NULL,
  `panacceptid` int(11) NOT NULL,
  `aadhaaracceptid` int(11) NOT NULL,
  `bankacceptid` int(11) NOT NULL,
  `leftreward` int(11) NOT NULL,
  `rightreward` int(11) NOT NULL,
  `gapcomid` int(11) NOT NULL DEFAULT '0',
  `usdt` text NOT NULL,
  `trx` text NOT NULL,
  `nfive` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (1, 1, '', 'Company ID', '', '', 'Company ID', '1998-07-09 00:00:00', 'M', '0', '', '9999999999', '0', '', '2726', '22', '', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (2, 2, '', 'DINIVA', '', '', 'DINIVA', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'rajkot', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (3, 3, '', 'DINIVA', '', '', 'DINIVA', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'london ', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (4, 4, '', 'DINIVA', '', '', 'DINIVA', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (5, 5, '', 'DINIVA', '', '', 'DINIVA', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (6, 6, '', 'DINIVA', '', '', 'DINIVA', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (7, 7, '', 'DINIVA 1', '', '', 'DINIVA 1', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '360005', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (8, 8, '', 'DINIVA 1', '', '', 'DINIVA 1', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (9, 9, '', 'DINIVA 1', '', '', 'DINIVA 1', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London ', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (10, 10, '', 'DINIVA 1', '', '', 'DINIVA 1', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (11, 11, '', 'DINIVA 1', '', '', 'DINIVA 1', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London ', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (12, 12, '', 'DINIVA 2', '', '', 'DINIVA 2', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (13, 13, '', 'DINIVA 2', '', '', 'DINIVA 2', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London ', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (14, 14, '', 'DINIVA 2', '', '', 'DINIVA 2', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (15, 15, '', 'DINIVA 2', '', '', 'DINIVA 2', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London ', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (16, 16, '', 'DINIVA 2', '', '', 'DINIVA 2', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London ', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (17, 17, '', 'DINIVA 3', '', '', 'DINIVA 3', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (18, 18, '', 'DINIVA 3', '', '', 'DINIVA 3', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (19, 19, '', 'DINIVA 3', '', '', 'DINIVA 3', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London ', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (20, 20, '', 'DINIVA 3', '', '', 'DINIVA 3', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (21, 21, '', 'DINIVA 3', '', '', 'DINIVA 3', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (22, 22, '', 'DINIVA 4', '', '', 'DINIVA 4', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (23, 23, '', 'DINIVA 4', '', '', 'DINIVA 4', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (24, 24, '', 'DINIVA 4', '', '', 'DINIVA 4', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (25, 25, '', 'DINIVA 4', '', '', 'DINIVA 4', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (26, 26, '', 'DINIVA 4', '', '', 'DINIVA 4', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'London', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');
INSERT INTO `mlm_userdetail` (`id`, `userid`, `title`, `fname`, `mname`, `lname`, `fullname`, `dob`, `sex`, `regtype`, `email`, `mobile`, `whatsapp`, `address`, `city`, `state`, `country`, `bankname`, `banktype`, `bankifsc`, `bankaccno`, `bankbranch`, `bankaccname`, `panno`, `pincode`, `nominee`, `nomineerel`, `profile`, `district`, `secretque`, `secretans`, `maritalstatus`, `occupation`, `micrcode`, `aadharcard`, `panacceptid`, `aadhaaracceptid`, `bankacceptid`, `leftreward`, `rightreward`, `gapcomid`, `usdt`, `trx`, `nfive`) VALUES (27, 27, '', 'kaushal nandha', '', '', 'kaushal nandha', '', '', '0', 'kaushal.nandha@gmail.com', '9725233634', '0', 'rajkot', '1011', '12', '101', NULL, NULL, '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, '', '', '');


#
# TABLE STRUCTURE FOR: mlm_userlogin
#

DROP TABLE IF EXISTS `mlm_userlogin`;

CREATE TABLE `mlm_userlogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `activedate` datetime DEFAULT NULL,
  `purchasestatus` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=Inactive 1=Active',
  `puchasedate` datetime NOT NULL,
  `activestatus` enum('0','1') NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `usernamechange` enum('yes','no') NOT NULL DEFAULT 'no',
  `clubid` int(2) NOT NULL DEFAULT '1',
  `status` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0: Member 1: Visitor',
  `statusdate` datetime NOT NULL,
  `lastlogindate` datetime NOT NULL,
  `currlogindate` datetime NOT NULL,
  `lastloginip` varchar(50) NOT NULL,
  `currloginip` varchar(50) NOT NULL,
  `lastpayoutdate` datetime NOT NULL,
  `packagecode` int(11) NOT NULL,
  `securitypassword` varchar(500) DEFAULT NULL,
  `kyc` int(11) NOT NULL,
  `panstatus` enum('0','1','2','3') NOT NULL COMMENT '0: Not Uploaded, 1: Accept, 2: Reject, 3: Pending ',
  `bankstatus` enum('0','1','2','3') NOT NULL COMMENT '0: Not Uploaded, 1: Accept, 2: Reject, 3: Pending ',
  `adharstatus` enum('0','1','2','3') NOT NULL COMMENT '0: Not Uploaded, 1: Accept, 2: Reject, 3: Pending ',
  `lastbinarydate` datetime NOT NULL,
  `bfl` float NOT NULL,
  `bfr` float NOT NULL,
  `tail` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0 : No, 1: Yes',
  `taildate` datetime NOT NULL,
  `bflbv` float NOT NULL,
  `bfrbv` float NOT NULL,
  `lockmember` enum('0','1','2') NOT NULL COMMENT '0=unlock 1=lock 2=softlock',
  `lockdate` datetime NOT NULL,
  `designation` int(11) NOT NULL,
  `sleft` int(11) NOT NULL,
  `sright` int(11) NOT NULL,
  `memtype` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=default 1=master',
  `boosterLeft` int(11) NOT NULL,
  `boosterRight` int(11) NOT NULL,
  `joinfrom` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0:web,1:android,2:ios',
  `leaderid` int(11) NOT NULL,
  `tmpleaderid` int(11) NOT NULL,
  `rightsponsor` int(11) NOT NULL,
  `leftsponsor` int(11) NOT NULL,
  `inactivesponsor` int(11) NOT NULL,
  `activeleftsponsor` int(11) NOT NULL,
  `activerightsponsor` int(11) NOT NULL,
  `activesponsor` int(11) NOT NULL,
  `tensponsorincome` int(11) NOT NULL DEFAULT '0',
  `capping` int(11) NOT NULL,
  `oldcapping` int(11) NOT NULL,
  `totalmp` int(11) NOT NULL,
  `wocaptotalmp` int(11) NOT NULL,
  `totalcut` int(11) NOT NULL,
  `deliverflag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:false,1:true',
  `deliverdate` datetime NOT NULL,
  `rewardid` int(11) NOT NULL,
  `generationid` int(11) NOT NULL,
  `selfpurchase` float NOT NULL,
  `downlinepurchase` float NOT NULL,
  `previouspurchase` float NOT NULL,
  `per` float NOT NULL,
  `repurchasedate` datetime NOT NULL,
  `counttotalleg` int(11) NOT NULL DEFAULT '0',
  `royaltymp` float NOT NULL,
  `royaltymonthmp` float NOT NULL,
  `royaltyeligible` int(11) NOT NULL,
  `calculationdate` datetime NOT NULL,
  `expiredate` datetime NOT NULL,
  `renewal` enum('0','1') NOT NULL DEFAULT '0',
  `multiply` int(11) NOT NULL,
  `tmpreneal` enum('0','1') NOT NULL DEFAULT '0',
  `mainincome` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=No 1=Yes',
  `teambv` int(11) NOT NULL,
  `lastdate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `id` (`id`),
  KEY `activeleftsponsor` (`activeleftsponsor`),
  KEY `activerightsponsor` (`activerightsponsor`),
  KEY `activestatus` (`activestatus`),
  KEY `sleft` (`sleft`),
  KEY `sright` (`sright`),
  KEY `lastbinarydate` (`lastbinarydate`),
  KEY `bfl` (`bfl`),
  KEY `bfr` (`bfr`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (1, '2021-08-18 12:13:19', '2021-10-14 17:53:30', '1', '2021-10-14 14:57:15', '1', 'D336678', 'Kaushal@9899#', 'no', 3, '0', '0000-00-00 00:00:00', '2018-10-23 13:56:23', '2018-11-01 17:54:05', '', '', '2021-03-15 23:59:59', 1, '', 4, '0', '0', '0', '2021-05-01 23:59:59', '0', '29', '1', '2018-12-10 23:59:59', '0', '378.375', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '0', '71100', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '2021-05-06 23:59:59', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (2, '2022-03-29 21:28:30', '2022-03-29 21:36:28', '0', '0000-00-00 00:00:00', '1', 'D876132', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 2, 'Kaushal@9899@', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '5000', '66100', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (3, '2022-03-31 02:03:14', '2022-03-31 02:05:40', '0', '0000-00-00 00:00:00', '1', 'D958327', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (4, '2022-03-31 02:07:29', '2022-03-31 02:15:01', '0', '0000-00-00 00:00:00', '1', 'D748259', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (5, '2022-03-31 02:16:54', '2022-03-31 02:18:04', '0', '0000-00-00 00:00:00', '1', 'D147325', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (6, '2022-03-31 02:19:11', '2022-03-31 02:20:09', '0', '0000-00-00 00:00:00', '1', 'D357894', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (7, '2022-03-31 02:21:48', '2022-03-31 02:24:36', '0', '0000-00-00 00:00:00', '1', 'D419527', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 3, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50000', '15900', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (8, '2022-03-31 02:28:15', '2022-03-31 02:34:19', '0', '0000-00-00 00:00:00', '1', 'D973241', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (9, '2022-03-31 02:35:29', '2022-03-31 02:36:32', '0', '0000-00-00 00:00:00', '1', 'D371826', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (10, '2022-03-31 02:37:41', '2022-03-31 02:38:40', '0', '0000-00-00 00:00:00', '1', 'D348716', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (11, '2022-03-31 02:40:04', '2022-03-31 02:41:14', '0', '0000-00-00 00:00:00', '1', 'D682453', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (12, '2022-03-31 02:43:10', '2022-03-31 02:44:36', '0', '0000-00-00 00:00:00', '1', 'D135689', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 2, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '5000', '10700', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (13, '2022-03-31 02:59:44', '2022-03-31 03:00:47', '0', '0000-00-00 00:00:00', '1', 'D498153', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (14, '2022-03-31 03:02:20', '2022-03-31 03:03:18', '0', '0000-00-00 00:00:00', '1', 'D738246', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (15, '2022-03-31 03:04:19', '2022-03-31 03:05:29', '0', '0000-00-00 00:00:00', '1', 'D846251', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (16, '2022-03-31 03:07:29', '2022-03-31 03:08:49', '0', '0000-00-00 00:00:00', '1', 'D235819', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (17, '2022-03-31 03:15:23', '2022-03-31 03:16:41', '0', '0000-00-00 00:00:00', '1', 'D428917', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 2, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '5000', '5500', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (18, '2022-03-31 03:19:02', '2022-03-31 03:20:01', '0', '0000-00-00 00:00:00', '1', 'D671428', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (19, '2022-03-31 03:21:04', '2022-03-31 03:21:58', '0', '0000-00-00 00:00:00', '1', 'D813754', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (20, '2022-03-31 03:22:59', '2022-03-31 03:24:07', '0', '0000-00-00 00:00:00', '1', 'D189435', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (21, '2022-03-31 03:25:21', '2022-03-31 03:27:17', '0', '0000-00-00 00:00:00', '1', 'D678451', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (22, '2022-03-31 03:36:50', '2022-03-31 03:38:00', '0', '0000-00-00 00:00:00', '1', 'D916254', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 2, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '5000', '300', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (23, '2022-03-31 03:39:59', '2022-03-31 03:41:14', '0', '0000-00-00 00:00:00', '1', 'D138726', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (24, '2022-03-31 03:42:21', '2022-03-31 03:44:29', '0', '0000-00-00 00:00:00', '1', 'D391627', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (25, '2022-03-31 03:45:36', '2022-03-31 03:46:37', '0', '0000-00-00 00:00:00', '1', 'D175324', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (26, '2022-03-31 03:48:00', '2022-03-31 03:48:58', '0', '0000-00-00 00:00:00', '1', 'D853941', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '50', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');
INSERT INTO `mlm_userlogin` (`id`, `entrydate`, `activedate`, `purchasestatus`, `puchasedate`, `activestatus`, `username`, `password`, `usernamechange`, `clubid`, `status`, `statusdate`, `lastlogindate`, `currlogindate`, `lastloginip`, `currloginip`, `lastpayoutdate`, `packagecode`, `securitypassword`, `kyc`, `panstatus`, `bankstatus`, `adharstatus`, `lastbinarydate`, `bfl`, `bfr`, `tail`, `taildate`, `bflbv`, `bfrbv`, `lockmember`, `lockdate`, `designation`, `sleft`, `sright`, `memtype`, `boosterLeft`, `boosterRight`, `joinfrom`, `leaderid`, `tmpleaderid`, `rightsponsor`, `leftsponsor`, `inactivesponsor`, `activeleftsponsor`, `activerightsponsor`, `activesponsor`, `tensponsorincome`, `capping`, `oldcapping`, `totalmp`, `wocaptotalmp`, `totalcut`, `deliverflag`, `deliverdate`, `rewardid`, `generationid`, `selfpurchase`, `downlinepurchase`, `previouspurchase`, `per`, `repurchasedate`, `counttotalleg`, `royaltymp`, `royaltymonthmp`, `royaltyeligible`, `calculationdate`, `expiredate`, `renewal`, `multiply`, `tmpreneal`, `mainincome`, `teambv`, `lastdate`) VALUES (27, '2022-03-31 03:50:16', '2022-03-31 03:51:14', '0', '0000-00-00 00:00:00', '1', 'D675824', 'Kaushal@9899#', 'no', 1, '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '0000-00-00 00:00:00', 1, 'Kaushal@9899#', 0, '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '0', '0000-00-00 00:00:00', 0, 0, 0, '0', 0, 0, '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0', '0000-00-00 00:00:00', 0, 0, '100', '0', '0', '0', '0000-00-00 00:00:00', 0, '0', '0', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 0, '0', '0', 0, '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: mlm_userdownline
#

DROP TABLE IF EXISTS `mlm_userdownline`;

CREATE TABLE `mlm_userdownline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `sponsor` int(11) NOT NULL,
  `upline` int(11) NOT NULL,
  `side` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0:left,1:middle,2:right',
  `lockplace` int(11) NOT NULL DEFAULT '0',
  `monthleftpv` float NOT NULL,
  `leftbv` float NOT NULL,
  `monthrightpv` float NOT NULL,
  `rightbv` float NOT NULL,
  `mp` float NOT NULL,
  `capping` float NOT NULL,
  `directincome` float NOT NULL,
  `eligible` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0- yes, 1-No',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `sponsor` (`sponsor`),
  KEY `upline` (`upline`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (1, 2, 1, 1, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (2, 3, 2, 2, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (3, 4, 2, 2, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (4, 5, 2, 2, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (5, 6, 2, 2, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (6, 7, 2, 2, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (7, 8, 7, 7, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (8, 9, 7, 7, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (9, 10, 7, 7, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (10, 11, 7, 7, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (11, 12, 7, 7, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (12, 13, 12, 12, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (13, 14, 12, 12, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (14, 15, 12, 12, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (15, 16, 12, 12, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (16, 17, 12, 12, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (17, 18, 17, 17, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (18, 19, 17, 17, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (19, 20, 17, 17, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (20, 21, 17, 17, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (21, 22, 17, 17, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (22, 23, 22, 22, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (23, 24, 22, 22, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (24, 25, 22, 22, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (25, 26, 22, 22, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `mlm_userdownline` (`id`, `userid`, `sponsor`, `upline`, `side`, `lockplace`, `monthleftpv`, `leftbv`, `monthrightpv`, `rightbv`, `mp`, `capping`, `directincome`, `eligible`) VALUES (26, 27, 22, 22, '2', 0, '0', '0', '0', '0', '0', '0', '0', '0');


#
# TABLE STRUCTURE FOR: mlm_useractivation
#

DROP TABLE IF EXISTS `mlm_useractivation`;

CREATE TABLE `mlm_useractivation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `activedate` datetime DEFAULT NULL COMMENT 'Status Update Date',
  `userid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `packagecode` int(11) NOT NULL,
  `activetype` enum('0','1') NOT NULL COMMENT '0:pin 1=wallet',
  `activepin` varchar(100) NOT NULL,
  `activeamount` float NOT NULL,
  `packagetax` float NOT NULL,
  `netamount` float NOT NULL,
  `bv` float NOT NULL,
  `pv` float NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0:accept,1:pending,2:reject',
  `statusby` int(10) NOT NULL,
  `type` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:Registration,1:Topup',
  `kitid` int(11) NOT NULL,
  `dispatch` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=No 1=Yes',
  `dispatchdate` datetime NOT NULL,
  `dispatchby` int(11) NOT NULL,
  `docateno` varchar(100) NOT NULL,
  `lockpackage` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=No 1=Yes',
  `joinfrom` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0:web,1:android,2:ios',
  `olddata` int(11) NOT NULL,
  `renew` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrydate` (`entrydate`),
  KEY `activedate` (`activedate`),
  KEY `pv` (`pv`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (1, '2022-03-29 21:36:28', '2022-03-29 21:36:28', 2, 2, 2, '1', '2', '5000', '0', '50000', '50000', '50000', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (2, '2022-03-31 02:05:40', '2022-03-31 02:05:40', 3, 3, 1, '1', '13', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (3, '2022-03-31 02:15:01', '2022-03-31 02:15:01', 4, 4, 1, '1', '16', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (4, '2022-03-31 02:18:04', '2022-03-31 02:18:04', 5, 5, 1, '1', '19', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (5, '2022-03-31 02:20:09', '2022-03-31 02:20:09', 6, 6, 1, '1', '22', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (6, '2022-03-31 02:24:36', '2022-03-31 02:24:36', 7, 7, 3, '1', '25', '50000', '0', '500000', '500000', '500000', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (7, '2022-03-31 02:34:19', '2022-03-31 02:34:19', 8, 8, 1, '1', '28', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (8, '2022-03-31 02:36:32', '2022-03-31 02:36:32', 9, 9, 1, '1', '31', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (9, '2022-03-31 02:38:40', '2022-03-31 02:38:40', 10, 10, 1, '1', '34', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (10, '2022-03-31 02:41:14', '2022-03-31 02:41:14', 11, 11, 1, '1', '37', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (11, '2022-03-31 02:44:36', '2022-03-31 02:44:36', 12, 12, 2, '1', '40', '5000', '0', '50000', '50000', '50000', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (12, '2022-03-31 03:00:47', '2022-03-31 03:00:47', 13, 13, 1, '1', '43', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (13, '2022-03-31 03:03:18', '2022-03-31 03:03:18', 14, 14, 1, '1', '46', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (14, '2022-03-31 03:05:29', '2022-03-31 03:05:29', 15, 15, 1, '1', '49', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (15, '2022-03-31 03:08:49', '2022-03-31 03:08:49', 16, 16, 1, '1', '52', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (16, '2022-03-31 03:16:41', '2022-03-31 03:16:41', 17, 17, 2, '1', '55', '5000', '0', '50000', '50000', '50000', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (17, '2022-03-31 03:20:01', '2022-03-31 03:20:01', 18, 18, 1, '1', '58', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (18, '2022-03-31 03:21:58', '2022-03-31 03:21:58', 19, 19, 1, '1', '61', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (19, '2022-03-31 03:24:07', '2022-03-31 03:24:07', 20, 20, 1, '1', '64', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (20, '2022-03-31 03:27:17', '2022-03-31 03:27:17', 21, 21, 1, '1', '67', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (21, '2022-03-31 03:38:00', '2022-03-31 03:38:00', 22, 22, 2, '1', '70', '5000', '0', '50000', '50000', '50000', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (22, '2022-03-31 03:41:14', '2022-03-31 03:41:14', 23, 23, 1, '1', '73', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (23, '2022-03-31 03:44:29', '2022-03-31 03:44:29', 24, 24, 1, '1', '76', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (24, '2022-03-31 03:46:37', '2022-03-31 03:46:37', 25, 25, 1, '1', '79', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (25, '2022-03-31 03:48:58', '2022-03-31 03:48:58', 26, 26, 1, '1', '82', '50', '0', '500', '500', '500', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');
INSERT INTO `mlm_useractivation` (`id`, `entrydate`, `activedate`, `userid`, `fromid`, `packagecode`, `activetype`, `activepin`, `activeamount`, `packagetax`, `netamount`, `bv`, `pv`, `status`, `statusby`, `type`, `kitid`, `dispatch`, `dispatchdate`, `dispatchby`, `docateno`, `lockpackage`, `joinfrom`, `olddata`, `renew`) VALUES (26, '2022-03-31 03:51:14', '2022-03-31 03:51:14', 27, 27, 1, '1', '85', '100', '0', '1000', '1000', '1000', '0', 0, '1', 0, '0', '0000-00-00 00:00:00', 0, '', '0', '0', 0, '0');


#
# TABLE STRUCTURE FOR: mlm_invoicedetail
#

DROP TABLE IF EXISTS `mlm_invoicedetail`;

CREATE TABLE `mlm_invoicedetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `orderno` varchar(50) NOT NULL,
  `ordertype` enum('SP','SR','FP','FR','FMP','FMR','MP','KIT','KITR','PD','PDR','VP') NOT NULL,
  `productid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `mrp` float NOT NULL,
  `dp` float NOT NULL,
  `fdp` float NOT NULL,
  `bv` float NOT NULL,
  `pv` float NOT NULL,
  `sgstper` float NOT NULL,
  `sgst` float NOT NULL,
  `cgstper` float NOT NULL,
  `cgst` float NOT NULL,
  `igstper` float NOT NULL,
  `igst` float NOT NULL,
  `totalmrp` float NOT NULL,
  `totaldp` float NOT NULL,
  `totalfdp` float NOT NULL,
  `status` enum('0','1','2','3','4','5','6','7','8','9') NOT NULL COMMENT '0:pending,1:accept,2:reject,3:request,4:dispatch,5:delivery,6:cancel,7:return pending,8:return accept,9:return reject  ',
  `updateby` int(11) NOT NULL,
  `updatedate` datetime NOT NULL,
  `rndsession` varchar(100) NOT NULL,
  `kitid` int(11) NOT NULL,
  `deliverycharge` float NOT NULL,
  `invoicepaymentid` int(11) NOT NULL,
  `storedp` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_invoicemaster
#

DROP TABLE IF EXISTS `mlm_invoicemaster`;

CREATE TABLE `mlm_invoicemaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `ordertype` enum('SP','SR','FP','FR','FMP','FMR','MP','KIT','KITR','PD','PDR','VP') NOT NULL,
  `qty` int(11) NOT NULL,
  `orderby` int(11) NOT NULL COMMENT 'userid,receiver',
  `orderfrom` int(11) NOT NULL,
  `invoiceno` varchar(50) NOT NULL,
  `invoiceserial` varchar(100) NOT NULL,
  `invoicedate` datetime DEFAULT NULL,
  `activepurchase` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=no 1=yes',
  `mrp` float NOT NULL,
  `dp` float NOT NULL,
  `bv` float NOT NULL,
  `pv` float NOT NULL,
  `addedby` int(11) NOT NULL,
  `status` enum('0','1','2','3','4','5','6','7','8','9') NOT NULL COMMENT '0:pending,1:accept,2:reject,3:request,4:dispatch,5:delivery,6:cancel,7:return pending,8:return accept,9:return  reject ',
  `updateby` int(11) NOT NULL,
  `updatedate` datetime NOT NULL,
  `fdp` float NOT NULL,
  `sgst` float NOT NULL,
  `cgst` float NOT NULL,
  `igst` float NOT NULL,
  `netamount` float NOT NULL,
  `deliverycharge` int(11) NOT NULL,
  `interstate` enum('0','1') NOT NULL COMMENT '0:false,1:true',
  `paymentmode` enum('0','1','2','3','4','5','6','7') NOT NULL COMMENT '0:Cash,1:DD/Cheque,2:Neft/RTGS,3:repurchase wallet,4:DC,5:CC,6:net banking,7:online payment',
  `transactionno` varchar(100) NOT NULL,
  `proof` text NOT NULL,
  `paymentstatus` enum('paid','unpaid') NOT NULL,
  `walletuse` enum('no','yes') NOT NULL,
  `ewalletamount` float NOT NULL,
  `remaingamount` float NOT NULL,
  `req` enum('no','yes') NOT NULL,
  `kit` enum('no','yes') NOT NULL,
  `discount` float NOT NULL,
  `address` text NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `shipping` float NOT NULL,
  `email` varchar(100) NOT NULL,
  `pdfpath` text NOT NULL,
  `pdfupload` enum('no','yes') NOT NULL,
  `delivarymode` varchar(100) NOT NULL,
  `remark` text NOT NULL,
  `sremark` text NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `returndate` datetime NOT NULL,
  `incomestatus` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:pending,1:done',
  `canceldate` datetime NOT NULL,
  `returnacceptdate` datetime NOT NULL,
  `returnrejectdate` datetime NOT NULL,
  `incomedate` datetime NOT NULL,
  `firstorder` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:false,1:true',
  `transactionid` text NOT NULL,
  `transactionstatus` text NOT NULL,
  `transactionmsg` text NOT NULL,
  `paymentresponse` text NOT NULL,
  `docketno` varchar(100) NOT NULL,
  `couriername` varchar(100) NOT NULL,
  `deliveryremarks` text NOT NULL,
  `storedp` float NOT NULL,
  `activeid` int(11) NOT NULL,
  `view` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_levelincome
#

DROP TABLE IF EXISTS `mlm_levelincome`;

CREATE TABLE `mlm_levelincome` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `levelno` int(11) NOT NULL,
  `structurelevel` int(11) NOT NULL,
  `perc` float NOT NULL,
  `amount` float NOT NULL,
  `tds` float NOT NULL,
  `netamount` float NOT NULL,
  `refid` int(11) NOT NULL,
  `type` enum('0','1') NOT NULL DEFAULT '0' COMMENT '1: Upline Distribution, 0: Downline Distribution',
  `admincharge` float NOT NULL,
  `repurchaseamount` float NOT NULL,
  `selfpurchase` float NOT NULL,
  `status` enum('0','1','3') NOT NULL DEFAULT '0' COMMENT '0=Pending 1=Accept 3=Reject',
  `remark` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entrydate` (`entrydate`),
  KEY `netamount` (`netamount`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_packagesetting
#

DROP TABLE IF EXISTS `mlm_packagesetting`;

CREATE TABLE `mlm_packagesetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `packagename` varchar(100) NOT NULL,
  `activestatus` enum('0','1','2','3') NOT NULL DEFAULT '1' COMMENT '0: Free, 1: Active, 2: Only For Topup 3 : Purchase',
  `priority` int(11) NOT NULL,
  `fromamount` float NOT NULL,
  `toamount` float NOT NULL,
  `mrp` float NOT NULL,
  `tax` float NOT NULL,
  `netmrp` float NOT NULL,
  `lockPackage` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:no,1:yes',
  `editFlag` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0:no,1:yes',
  `pv` float NOT NULL,
  `bv` float NOT NULL,
  `binaryperc` float NOT NULL,
  `capping` float NOT NULL,
  `shoppingbal` float NOT NULL,
  `roi` float NOT NULL,
  `roidays` int(11) NOT NULL,
  `roiinterval` int(11) NOT NULL,
  `directper` float NOT NULL,
  `directamt` float NOT NULL,
  `total` int(11) NOT NULL,
  `used` int(11) NOT NULL,
  `unused` int(11) NOT NULL,
  `addedby` int(11) NOT NULL,
  `view` enum('view','close') NOT NULL,
  `updatedate` datetime NOT NULL,
  `updateby` int(11) NOT NULL,
  `kitid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_packagesetting` (`id`, `entrydate`, `packagename`, `activestatus`, `priority`, `fromamount`, `toamount`, `mrp`, `tax`, `netmrp`, `lockPackage`, `editFlag`, `pv`, `bv`, `binaryperc`, `capping`, `shoppingbal`, `roi`, `roidays`, `roiinterval`, `directper`, `directamt`, `total`, `used`, `unused`, `addedby`, `view`, `updatedate`, `updateby`, `kitid`) VALUES (1, '2018-09-17 00:00:00', 'Ruby', '1', 1, '50', '2999', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0.2857', 700, 1, '8', '0', 0, 0, 0, 0, 'view', '2019-09-03 15:59:27', 0, 0);
INSERT INTO `mlm_packagesetting` (`id`, `entrydate`, `packagename`, `activestatus`, `priority`, `fromamount`, `toamount`, `mrp`, `tax`, `netmrp`, `lockPackage`, `editFlag`, `pv`, `bv`, `binaryperc`, `capping`, `shoppingbal`, `roi`, `roidays`, `roiinterval`, `directper`, `directamt`, `total`, `used`, `unused`, `addedby`, `view`, `updatedate`, `updateby`, `kitid`) VALUES (2, '2018-09-17 00:00:00', 'Diamond', '1', 1, '3000', '9999', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0.3214', 560, 1, '8', '0', 0, 0, 0, 0, 'view', '2019-09-03 15:59:27', 0, 0);
INSERT INTO `mlm_packagesetting` (`id`, `entrydate`, `packagename`, `activestatus`, `priority`, `fromamount`, `toamount`, `mrp`, `tax`, `netmrp`, `lockPackage`, `editFlag`, `pv`, `bv`, `binaryperc`, `capping`, `shoppingbal`, `roi`, `roidays`, `roiinterval`, `directper`, `directamt`, `total`, `used`, `unused`, `addedby`, `view`, `updatedate`, `updateby`, `kitid`) VALUES (3, '2018-09-17 00:00:00', 'Pearl', '1', 1, '10000', '1000000', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0.3571', 420, 1, '8', '0', 0, 0, 0, 0, 'view', '2019-09-03 15:59:27', 0, 0);


#
# TABLE STRUCTURE FOR: mlm_productmaster
#

DROP TABLE IF EXISTS `mlm_productmaster`;

CREATE TABLE `mlm_productmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `entrydate` datetime NOT NULL,
  `productname` varchar(255) NOT NULL,
  `subtitle` text NOT NULL,
  `packagecode` int(11) NOT NULL,
  `model` varchar(50) NOT NULL,
  `kit` enum('yes','no') NOT NULL DEFAULT 'no',
  `mrp` float NOT NULL,
  `dp` float NOT NULL,
  `fdp` float NOT NULL,
  `bv` float NOT NULL,
  `pv` float NOT NULL,
  `hsnid` int(11) NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0 : view 1: hide 2: delete',
  `profile` text NOT NULL,
  `netmrp` float NOT NULL,
  `netdp` float NOT NULL,
  `netfdp` float NOT NULL,
  `sgstper` float NOT NULL,
  `sgst` float NOT NULL,
  `discount` float NOT NULL,
  `cgstper` float NOT NULL,
  `cgst` float NOT NULL,
  `igstper` float NOT NULL,
  `igst` float NOT NULL,
  `openingstock` int(11) NOT NULL,
  `description` text NOT NULL,
  `addedby` int(11) NOT NULL,
  `lastupdatedate` datetime NOT NULL,
  `deliverycharge` float NOT NULL,
  `onlyadmin` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=All 1=Admin',
  `rentamount` float NOT NULL,
  `timerent` int(11) NOT NULL COMMENT 'In Month',
  `renewal` float NOT NULL,
  `timerenewal` int(11) NOT NULL COMMENT 'In Month',
  `shoppeamount` float NOT NULL,
  `timeshopee` int(11) NOT NULL COMMENT 'In Month',
  `activationview` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=view 1=No',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_walletmaster
#

DROP TABLE IF EXISTS `mlm_walletmaster`;

CREATE TABLE `mlm_walletmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `amount` float NOT NULL,
  `remark` text NOT NULL,
  `status` enum('0','1','2') NOT NULL COMMENT '0:pending 1:Accept 2:Reject',
  `statusdate` datetime NOT NULL,
  `statusby` int(11) NOT NULL,
  `proof` text NOT NULL,
  `accnumber` varchar(50) NOT NULL,
  `acctype` varchar(50) NOT NULL,
  `reqtype` enum('0','1','2') NOT NULL COMMENT '0: Added By Admin 1: Request 2: Transfer',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_walletorder
#

DROP TABLE IF EXISTS `mlm_walletorder`;

CREATE TABLE `mlm_walletorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `type` enum('0','1') NOT NULL COMMENT '0:Credit,1:Debit',
  `reqtype` enum('0','1') NOT NULL COMMENT '0:Admin,1:Member',
  `amount` int(11) NOT NULL,
  `status` enum('0','1','2','3','4','5') NOT NULL COMMENT '0:Pending,1:Accept,2:Reject,3:pending payment,4:accept payment,5:reject payment',
  `statusdate` datetime DEFAULT NULL,
  `statusby` int(11) NOT NULL,
  `proof` text NOT NULL,
  `paymentmode` enum('0','1','2','3') DEFAULT NULL COMMENT '0:cash,1:NEFT,2:cheque	,3:online payment',
  `remarks` varchar(100) NOT NULL,
  `transactionId` varchar(50) NOT NULL,
  `response` text NOT NULL,
  `onlinepaymentamount` float NOT NULL,
  `paymentgatewayid` text NOT NULL,
  `view` enum('0','1') NOT NULL DEFAULT '0',
  `buyprice` float NOT NULL,
  `coinprice` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (1, '2022-03-29 21:34:09', 2, '0', '1', 5000, '1', '2022-03-29 21:34:49', 2, '1648569849.png', '0', '', 'gdryt6y7uhibjghfcrdyt67y8ouihjkbjvghcfxrdytfuiy7ou', '', '0', '', '0', '0.1', '50000');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (2, '2022-03-31 02:05:17', 3, '0', '1', 50, '1', '2022-03-31 02:05:28', 2, '1648672517.png', '0', '', 'dxert657t8yiuhgvcfxdrt65t78y9uoi', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (3, '2022-03-31 02:14:41', 4, '0', '1', 50, '1', '2022-03-31 02:14:49', 2, '1648673081.png', '0', '', 'guy789uihytg678y9uihbygu8798', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (4, '2022-03-31 02:17:34', 5, '0', '1', 50, '1', '2022-03-31 02:17:41', 2, '1648673254.png', '0', '', 'grbefwrg342ewrt453245e', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (5, '2022-03-31 02:19:49', 6, '0', '1', 50, '1', '2022-03-31 02:19:59', 2, '1648673388.png', '0', '', 'ygd87f9ueijwhuygr8u90io23eww3ew', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (6, '2022-03-31 02:22:28', 7, '0', '1', 50000, '1', '2022-03-31 02:22:33', 2, '1648673548.png', '0', '', 'cgdtryf768yhuibvgctyrf768t9yi', '', '0', '', '0', '0.1', '500000');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (7, '2022-03-31 02:33:59', 8, '0', '1', 50, '1', '2022-03-31 02:34:08', 2, '1648674239.png', '0', '', 'gdxtryt678y9oihjgvctyrd567t8oi', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (8, '2022-03-31 02:36:14', 9, '0', '1', 50, '1', '2022-03-31 02:36:24', 2, '1648674374.png', '0', '', 'guy8hu90ijohgvuy879h8iojnhyuh8', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (9, '2022-03-31 02:38:25', 10, '0', '1', 50, '1', '2022-03-31 02:38:32', 2, '1648674504.png', '0', '', 'fcty768y9hoiujbkhgfcytug7ihojknjhgtuyg78i', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (10, '2022-03-31 02:40:53', 11, '0', '1', 50, '1', '2022-03-31 02:41:03', 2, '1648674653.png', '0', '', 'gy789uiuhgvt6g87y9iouhyvg879i', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (11, '2022-03-31 02:44:12', 12, '0', '1', 5000, '1', '2022-03-31 02:44:23', 2, '1648674852.png', '0', '', 'crdytfu687y8ouihjbkvgchfdrytfu687t9y8i', '', '0', '', '0', '0.1', '50000');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (12, '2022-03-31 03:00:24', 13, '0', '1', 50, '1', '2022-03-31 03:00:37', 2, '1648675824.png', '0', '', 'gty78f9gu0ery78tu43iurye7t9834', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (13, '2022-03-31 03:03:04', 14, '0', '1', 50, '1', '2022-03-31 03:03:09', 2, '1648675984.png', '0', '', 'dxtr65t78yhiubyvgcfhrxydtf6789yi', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (14, '2022-03-31 03:05:10', 15, '0', '1', 50, '1', '2022-03-31 03:05:19', 2, '1648676110.png', '0', '', 'fgcty768y9hioubvgtfy768y90upijoubhvyug789', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (15, '2022-03-31 03:08:30', 16, '0', '1', 50, '1', '2022-03-31 03:08:40', 2, '1648676310.png', '0', '', 'dxtr678yhiuyvgctyrdf678t9yoij', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (16, '2022-03-31 03:16:21', 17, '0', '1', 5000, '1', '2022-03-31 03:16:31', 2, '1648676781.png', '0', '', 'dxert657t8yhuiyvgcfrdytf678y9i', '', '0', '', '0', '0.1', '50000');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (17, '2022-03-31 03:19:44', 18, '0', '1', 50, '1', '2022-03-31 03:19:53', 2, '1648676984.png', '0', '', 'cdxtr678y9uhiougvtcyf687t9yiok', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (18, '2022-03-31 03:21:44', 19, '0', '1', 50, '1', '2022-03-31 03:21:49', 2, '1648677104.png', '0', '', 'dxtry678yuhiobjvgcfty687y9', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (19, '2022-03-31 03:23:44', 20, '0', '1', 50, '1', '2022-03-31 03:23:56', 2, '1648677224.png', '0', '', 'gvytg768y9uhigvtgy789ij', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (20, '2022-03-31 03:26:57', 21, '0', '1', 50, '1', '2022-03-31 03:27:05', 2, '1648677417.png', '0', '', 'fc6t78y9uhoibyvgtyf678y9u0piojj', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (21, '2022-03-31 03:37:32', 22, '0', '1', 5000, '1', '2022-03-31 03:37:41', 2, '1648678052.png', '0', '', 'grbe5fwrt453wert34', '', '0', '', '0', '0.1', '50000');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (22, '2022-03-31 03:40:52', 23, '0', '1', 50, '1', '2022-03-31 03:41:05', 2, '1648678252.png', '0', '', 'fgew34ewrty34ewrt34ewrty45t3efwrt', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (23, '2022-03-31 03:44:08', 24, '0', '1', 50, '1', '2022-03-31 03:44:15', 2, '1648678447.png', '0', '', 'gbrefuw89ijoru89iwrjgew', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (24, '2022-03-31 03:46:22', 25, '0', '1', 50, '1', '2022-03-31 03:46:27', 2, '1648678582.png', '0', '', 'fcrty768y9huiytcrdtf67879yiojhvuy789y8', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (25, '2022-03-31 03:48:43', 26, '0', '1', 50, '1', '2022-03-31 03:48:51', 2, '1648678723.png', '0', '', 'hytf7g68y9uihuyvgtfg789y80uijuyhvutg78', '', '0', '', '0', '0.1', '500');
INSERT INTO `mlm_walletorder` (`id`, `entrydate`, `userid`, `type`, `reqtype`, `amount`, `status`, `statusdate`, `statusby`, `proof`, `paymentmode`, `remarks`, `transactionId`, `response`, `onlinepaymentamount`, `paymentgatewayid`, `view`, `buyprice`, `coinprice`) VALUES (26, '2022-03-31 03:50:59', 27, '0', '1', 100, '1', '2022-03-31 03:51:06', 2, '1648678859.png', '0', '', 'xestdr6576t8yuhgytcfrxdt567879y8', '', '0', '', '0', '0.1', '1000');


#
# TABLE STRUCTURE FOR: mlm_gstmaster
#

DROP TABLE IF EXISTS `mlm_gstmaster`;

CREATE TABLE `mlm_gstmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `hsncode` varchar(50) NOT NULL,
  `sgst` float NOT NULL,
  `cgst` float NOT NULL,
  `igst` float NOT NULL,
  `addedby` int(11) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0:hide,1:show',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_repurchasedesignation
#

DROP TABLE IF EXISTS `mlm_repurchasedesignation`;

CREATE TABLE `mlm_repurchasedesignation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `wallet` int(11) NOT NULL,
  `wallettwo` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_levelmaster
#

DROP TABLE IF EXISTS `mlm_levelmaster`;

CREATE TABLE `mlm_levelmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `levelno` int(11) NOT NULL,
  `per` float NOT NULL,
  `amount` float NOT NULL,
  `pcode` int(11) NOT NULL,
  `reserve` float NOT NULL,
  `sponsor` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (1, 1, '25', '0', 0, '0', 1);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (2, 2, '15', '0', 0, '0', 2);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (3, 3, '10', '0', 0, '0', 3);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (4, 4, '8', '0', 0, '0', 4);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (5, 5, '5', '0', 0, '0', 5);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (6, 6, '5', '0', 0, '0', 5);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (7, 7, '5', '0', 0, '0', 5);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (8, 8, '5', '0', 0, '0', 5);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (9, 9, '5', '0', 0, '0', 5);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (10, 10, '5', '0', 0, '0', 5);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (11, 11, '3', '0', 0, '0', 5);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (12, 12, '3', '0', 0, '0', 5);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (13, 13, '3', '0', 0, '0', 5);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (14, 14, '1', '0', 0, '0', 5);
INSERT INTO `mlm_levelmaster` (`id`, `levelno`, `per`, `amount`, `pcode`, `reserve`, `sponsor`) VALUES (15, 15, '1', '0', 0, '0', 5);


#
# TABLE STRUCTURE FOR: mlm_pinmaster
#

DROP TABLE IF EXISTS `mlm_pinmaster`;

CREATE TABLE `mlm_pinmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `pinno` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `statusdate` datetime NOT NULL,
  `usedby` int(11) NOT NULL,
  `refid` int(11) NOT NULL,
  `packagecode` int(11) NOT NULL,
  `orderby` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:memberid,1:franchisee',
  `deleteid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pinno` (`pinno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_pintransaction
#

DROP TABLE IF EXISTS `mlm_pintransaction`;

CREATE TABLE `mlm_pintransaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `pinid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` varchar(50) NOT NULL,
  `type` enum('0','1','2','3','4','5') NOT NULL DEFAULT '0' COMMENT '0:Allocation,1:Member To Member Pin Transfer,2:Used for register,3:Used For Activation,4:Franchisee To Member Pin Transfer 5=Pin Generated',
  `refid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_pinorder
#

DROP TABLE IF EXISTS `mlm_pinorder`;

CREATE TABLE `mlm_pinorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` varchar(50) NOT NULL,
  `type` enum('0','1','3') NOT NULL COMMENT '0:Pin Allocate,1:Pin request accepted 3:Pin Generate',
  `status` varchar(100) NOT NULL,
  `statusdate` datetime NOT NULL,
  `pincount` int(11) NOT NULL,
  `remark` text NOT NULL,
  `proof` text NOT NULL,
  `packagecode` int(11) NOT NULL,
  `orderby` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:member,1franchisee',
  `amount` float NOT NULL,
  `tds` float NOT NULL,
  `admincharge` float NOT NULL,
  `netamount` float NOT NULL,
  `generateid` int(11) NOT NULL DEFAULT '0',
  `charge` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_withdrawalreq
#

DROP TABLE IF EXISTS `mlm_withdrawalreq`;

CREATE TABLE `mlm_withdrawalreq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `amount` float NOT NULL,
  `admincharge` float NOT NULL,
  `tds` float NOT NULL,
  `othercharge` float NOT NULL,
  `netamount` float NOT NULL,
  `status` enum('0','1','2') NOT NULL COMMENT '0:Pending, 1:Accept, 2: Reject',
  `statusby` varchar(100) NOT NULL,
  `statusdate` datetime NOT NULL,
  `remark` text NOT NULL,
  `bankname` text NOT NULL,
  `banktype` text,
  `bankifsc` text NOT NULL,
  `bankaccno` text NOT NULL,
  `bankbranch` text NOT NULL,
  `bankaccname` text NOT NULL,
  `joinfrom` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0:web,1:android,2:ios',
  `pmode` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0=USDT 1=TRX 2=NFIVE',
  `address` text NOT NULL,
  `sellprice` float NOT NULL,
  `dollar` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mlm_repurchaseincome
#

DROP TABLE IF EXISTS `mlm_repurchaseincome`;

CREATE TABLE `mlm_repurchaseincome` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entrydate` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `levelno` int(11) NOT NULL,
  `mainamount` int(11) NOT NULL,
  `perc` float NOT NULL,
  `amount` float NOT NULL,
  `tds` float NOT NULL,
  `netamount` float NOT NULL,
  `refid` int(11) NOT NULL,
  `type` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0:level income,1:binary income',
  `admincharge` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

